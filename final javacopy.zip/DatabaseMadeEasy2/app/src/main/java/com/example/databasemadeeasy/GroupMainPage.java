package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class GroupMainPage extends AppCompatActivity {

    String groupId;
    TextView title, description, link;
    ImageView backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_main_page);

        title = findViewById(R.id.textView16);
        description = findViewById(R.id.textView19);
        link = findViewById(R.id.textView20);
        backBtn = findViewById(R.id.imageView8);


        Bundle bundle = getIntent().getExtras();
        groupId = bundle.getString("groupId");


        DBManager dbManager = new DBManager(getApplicationContext());
        Cursor cursor = dbManager.open().fetchDataById("groups", groupId, "groupId");

        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                title.setText(cursor.getString(1));
                description.setText(cursor.getString(2));
                link.setText(cursor.getString(3));
            }
        }

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}