package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdminCourse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_course);
    }
}