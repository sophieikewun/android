package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Course_content extends AppCompatActivity {

    ImageView back_btn;
    TextView courseTitle, courseDescription;

    DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_content);

        back_btn = findViewById(R.id.back_btn);
        courseTitle = findViewById(R.id.courseTitle);
        courseDescription = findViewById(R.id.courseDescription);

        dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        Bundle bundle = getIntent().getExtras();
        Cursor cursor = dbManager.fetchDataById("course", bundle.getString("courseId"), "courseId");

        if(cursor.getCount() == 0) {

        }
        else {
            while(cursor.moveToNext()) {
                courseTitle.setText(cursor.getString(1));
                courseDescription.setText(cursor.getString(2));
            }
        }


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }
}