package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Signup extends AppCompatActivity {

    ImageView backBtn;
    Button signupBtn, loginBtn;
    EditText emailField, passwordField, fullNameField;
    TextView forgotPwdBtn, messageBox;

    SimpleDateFormat sdf3;
    DBManager dbManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        backBtn = findViewById(R.id.backBtn);
        signupBtn = findViewById(R.id.verifyBtn);
        loginBtn = findViewById(R.id.signInBtn);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        fullNameField = findViewById(R.id.fullNameField);
        forgotPwdBtn = findViewById(R.id.forgotPwdBtn);
        messageBox = findViewById(R.id.messageBox2);

        dbManager = new DBManager(getApplicationContext());
        sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Main_login.class));
            }
        });

        forgotPwdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Password_reset.class));
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailValue = emailField.getText().toString();
                String passwordValue = passwordField.getText().toString();
                String fullNameValue = fullNameField.getText().toString();

                if(emailValue.isEmpty() || passwordValue.isEmpty() || fullNameValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    if (Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
                        dbManager.open();
                        Cursor cursor = dbManager.fetchDataBySpecificColumn("user", emailValue, "email");

                        if(cursor.getCount() > 0) {
                            setMessageBox("Email exists");
                        } else {
                            int user_Id = (int) dbManager.insertUser(fullNameValue, emailValue, passwordValue, 0, 0);
                            int otp_code = (int) Math.floor(Math.random() * (90000 - 10000 + 1) + 10000);
                            String timeToExpire = sdf3.format(new Timestamp(System.currentTimeMillis() + 1000 * 60 * 30));

                            dbManager.insertOtp(user_Id, otp_code, timeToExpire);



                            Intent i = new Intent(v.getContext(), Verify_email.class);
                            i.putExtra("email", emailValue);
                            i.putExtra("userId", user_Id);

                            emailField.setText("");
                            passwordField.setText("");
                            fullNameField.setText("");
                            startActivity(i);
                        }

                    } else {
                        setMessageBox("Invalid email format");
                    }
                }
            }
        });

    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }
}