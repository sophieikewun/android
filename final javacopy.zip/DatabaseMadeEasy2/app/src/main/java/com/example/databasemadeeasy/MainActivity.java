package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.LinearLayout;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {

    LinearLayout mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //cc();

        mainLayout = findViewById(R.id.mainLayout);

        new CountDownTimer(3000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                startActivity(new Intent(getApplicationContext(), Welcome_page.class));
            }
        }.start();

//        mainLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(), Welcome_page.class));
//            }
//        });

    }


    public void cc() {
        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        dbManager.insertUser("Sample user", "sampleuser@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Sophia Ikewun", "sophiaikewun@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Ikewun Zoe", "ikewunzoe@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Zoe SAmple", "ikewunzoe1@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Smam Zoe", "ikewunzoe2@mail.com", "samplee", 0, 1);
        dbManager.insertUser("III Zoe", "ikewunzoe3@mail.com", "samplee", 0, 1);
        dbManager.insertUser("LMSDNK Zoe", "ikewunzoe4@mail.com", "samplee", 0, 1);
        dbManager.insertUser("MNVMN Zoe", "ikewunzoe5@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Kdjfdfn Zoe", "ikewunzoe6@mail.com", "samplee", 0, 1);
//
        dbManager.insertCategory("Beginner");
        dbManager.insertCategory("Intermediate");
        dbManager.insertCategory("Advanced");
        dbManager.insertCategory("Expert");
//
        dbManager.insertCourse("Introduction to Database", "The relational data model was first proposed by Edward Codd in a\n" +
                "paper written in 1970.\n" +
                "• The relational model has a sound theoretical foundation, which is\n" +
                "lacking in some of the other models.\n" +
                "• The objectives of the relational model are:\n" +
                "– To allow a high degree of data independence. Users’ interactions with the\n" +
                "database must not be affected by changes to the internal view of data,\n" +
                "particularly record orderings and access paths.\n" +
                "– To provide substantial grounds for dealing with the problems of data\n" +
                "semantics, consistency, and redundancy. In particular, Codd’s paper\n" +
                "introduces the concept of normalised relations (details later).\n" +
                "– To enable the use of set-oriented data manipulation languages " +
                "" +
                "One of the most significant implementations of the relational model\n" +
                "was System R which was developed by IBM during the late 1970’s.\n" +
                "• System R was intended as a “proof of concept” to show that relational\n" +
                "database systems could really be built and work efficiently.\n" +
                "• It gave rise to two major developments:\n" +
                "– A structured query language called SQL which has since become an ISO\n" +
                "standard and de facto standard relational language.\n" +
                "– The production of various commercial relational DBMS products during\n" +
                "the 1980s such as DB2, SQL/DS, and ORACLE.\n" +
                "• There are now several hundred relational database systems.\n" +
                "– Both commercial and open source" +
                "" +
                "The relational model is based on the mathematical concept of a\n" +
                "relation.\n" +
                "– Since Codd was a mathematician, he used terminology from that field, in\n" +
                "particular set theory and logic.\n" +
                "– We will not deal with these concepts as such, but we need to understand\n" +
                "the terminology as it relates to the relational data model.\n" +
                "• A relation is represented as a two-dimensional table containing rows\n" +
                "and columns (much like a spreadsheet).\n" +
                "• Relations are used to hold information about the entities to be\n" +
                "represented in the database.\n" +
                "– The rows correspond to individual records.\n" +
                "– The columns correspond to attributes or fields.\n" +
                "– The order of the attributes is unimportant. They can appear in any order\n" +
                "and the relation will remain the same.",  "Logically related data that represents the entities, attributes,\n" +
                "and relationships of an organisation’s information" , sdf3.format(new Timestamp(System.currentTimeMillis())),  1);

        dbManager.insertCourse("Database Keys", "We need to be able to identify uniquely each row in a relation by the\n" +
                "values of its attributes.\n" +
                "– This enables a particular row to be retrieved or related to other records.\n" +
                "• We use relational keys for this purpose. These consist of a chosen\n" +
                "attribute or set of attributes from the relation in question. " +
                "" +
                "Superkeys\n" +
                "• A superkey is any attribute or set of attributes that uniquely identifies a\n" +
                "particular row within a relation. Problem with Superkeys\n" +
                "• The problem with superkeys is that they may contain attributes that are\n" +
                "not strictly required for unique identification." +
                "Ideally, we are interested in the superkeys that contain only the\n" +
                "attributes necessary for unique identification. Candidate Keys\n" +
                "• If a superkey does not contain any superfluous attributes, we say\n" +
                "that it is minimal. More formally:\n" +
                "– A superkey is minimal if removing any attributes would mean that it no\n" +
                "longer provides unique identification.\n" +
                "• When choosing a key for a relation, we may pick any minimal\n" +
                "superkey. Minimal superkeys are therefore called candidate keys. Properties of Candidate Keys\n" +
                "• A candidate key, K, for a relation R has the following properties:\n" +
                "• Uniqueness:\n" +
                "– In each row of R, the values of K uniquely identify that row.\n" +
                "– In other words: no two rows of R can have the same values for K.\n" +
                "• Irreducibility:\n" +
                "– No subset of K has the uniqueness property.\n" +
                "– Therefore, K cannot consist of fewer attributes.\n" +
                "• The above is simply a formal way of stating what we know about\n" +
                "candidate keys.\n" +
                "• Some relations may have several candidate keys. " +
                "" +
                "Primary Keys " +
                "" +
                "For each relation in the database, we must choose one of its candidate\n" +
                "keys to be its primary key.\n" +
                "• Since a relation cannot have duplicate rows (by definition), it is always\n" +
                "possible to uniquely identify each row.\n" +
                "– This means that in theory every relation has at least one candidate key.\n" +
                "– Hence, a primary key can always be found.\n" +
                "– In the worst case, the entire set of attributes could serve as the primary\n" +
                "key, but usually some smaller subset is sufficient.\n" +
                "• However, since many database systems allow relations to contain\n" +
                "duplicates, this theoretical property does not necessarily apply in\n" +
                "practice. Foreign Key  When an attribute appears in more than one relation, its appearance\n" +
                "usually represents a relationship between records of the relations, When the primary key of one relation appears as an attribute in another\n" +
                "relation it is called a foreign key", "We need to be able to identify uniquely each row in a relation by the\n" +
                "values of its attributes.",sdf3.format(new Timestamp(System.currentTimeMillis())), 1  );




        dbManager.insertCourse("Database Design", "E(Enhanced)ER Modelling\n" +
                "• Complexity of the data make it difficult to use the traditional ER\n" +
                "model.\n" +
                "• To reduce this complexity of modelling:\n" +
                "– improvements or enhancements to the existing ER model to\n" +
                "make it able to handle the complex application in a better\n" +
                "way.\n" +
                "• A diagrammatic technique for displaying the Sub Class and\n" +
                "Super Class; Specialization and Generalization; Aggregation etc.\n" +
                "• It is based on developing the features for representing\n" +
                "supertype/subtype relationships. Generalization/Specialization\n" +
                "• Associated with special types of entities known as superclasses and\n" +
                "subclasses.\n" +
                "• Specialisation is the process of defining a set of subclasses.\n" +
                "• Specialized classes are often called subclass while a generalized class\n" +
                "is called a superclass." +
                "Superclasses and Subclasses\n" +
                "• An entity type represents a set of entities of the same type such as Staff,\n" +
                "Branch, and PropertyForRent. We can also form entity types into a\n" +
                "hierarchy containing superclasses and subclasses.\n" +
                "• Superclass: An entity type that includes one or more distinct\n" +
                "subgroupings of its occurrences, which require to be represented in a\n" +
                "data model:\n" +
                "• Subclass: A distinct subgrouping of occurrences of an entity type,\n" +
                "which require to be represented in a data model.\n" +
                "• For example, the entities that are members of the Staff entity type\n" +
                "may be classified as Manager, SalesPersonnel, and Secretary. In\n" +
                "other words, the Staff entity is referred to as the superclass of the Manager, SalesPersonnel, and Secretary subclasses.",

                "An entity–relationship model (or ER model) describes interrelated things of interest in a specific domain of knowledge. ", sdf3.format(new Timestamp(System.currentTimeMillis())), 2);





        dbManager.insertCourse("Advanced SQL", "Creating a Table\n" +
                "• The simplest form of SQL CREATE TABLE looks like:\n" +
                "CREATE TABLE IF NOT EXISTS tablename\n" +
                "(colname datatype,\n" +
                "... )\n" +
                "CREATE TABLE Staff\n" +
                "(Sno INT,\n" +
                "Sname VARCHAR2(20),\n" +
                "Dept VARCHAR2(20),\n" +
                "Grade VARCHAR2(7)) " +
                "" +
                "Data Types\n" +
                "• Data types include:\n" +
                "– VARCHAR2 variable length text strings\n" +
                "– INT integers\n" +
                "– DECIMAL numbers with decimal places\n" +
                "– DATE full date (yyyy-mm-dd)\n" +
                "• Dates have a default form of DD-MON-YY\n" +
                "• EG: ‘09-MAR-17’ The apostrophes are required.  Table Constraints\n" +
                "•    Data types " +
                "" +
                "The specification of a column can include some extras:\n" +
                "– default value (used if an insertion doesn't supply a value)\n" +
                "– and a column constraint (next slide)\n" +
                "• We can add table constraint(s) before the closing\n" +
                "bracket " +
                "" +
                " Data Integrity\n" +
                "• Column constraints\n" +
                "– enforcing entity and referential integrity\n" +
                "[NOT NULL | NULL]\n" +
                "[DEFAULT default_value]\n" +
                "[AUTO_INCREMENT]\n" +
                "[UNIQUE [KEY] | [PRIMARY] KEY]\n" +
                "[COMMENT 'string']\n" +
                "PRIMARY KEY (only one per table)\n" +
                "FOREIGN KEY REFERENCES table (column) " +
                "" +
                "Data Integrity: Foreign Keys\n" +
                "• The last of these declares a foreign key:\n" +
                "CREATE TABLE Staff\n" +
                "( ...\n" +
                "Dept VARCHAR2(20) FOREIGN KEY REFERENCES Depts(Dname),\n" +
                "Grade VARCHAR2(7) FOREIGN KEY REFERENCES Paytable\n" +
                ")", "advanced SQL subjects include transactions, normal forms, main and foreign keys, hierarchical queries, triggers, indices, stored procedures, and much more. ",  sdf3.format(new Timestamp(System.currentTimeMillis())), 2);





        dbManager.insertCourse( "Normalisation", "Normalisation of your database is a good thing\n" +
                "– It makes the storage of data more efficient\n" +
                "– It simplifies maintenance of the data\n" +
                "• There are lots of normal forms\n" +
                "– 1NF, 2NF, 3NF, BCNF, 4NF, 5NF\n" +
                "• We will go through some of these, identifying the problems at each stage to motivate the next\n" +
                "stage.\n" +
                "– We will stop at 3NF" +
                "" +
                " Normalisation\n" +
                "• What makes a well-designed set of relations? Are some relations better\n" +
                "than others? Do we know what a relation is?\n" +
                "• Also, what should we do if we are given an informally set-up table of data\n" +
                "and asked to convert this to a relational database?\n" +
                "• Usually, if we have designed a database from scratch using E-R modelling,\n" +
                "we will end up with a well-designed set of relations.\n" +
                "• But in other cases, we need to apply normalisation.\n" +
                "• Example: We are given a table of newspaper readers and the newspapers\n" +
                "they read. For example, reader Smith likes to read the Record and the Mail.\n" +
                "We are asked to transform this table into a database. Achieving 1NF\n" +
                "9\n" +
                "• In general, to achieve 1NF we need to get rid of repeating groups in our tables. There are two\n" +
                "alternative ways of doing this.\n" +
                "• The one-table approach: we extend the table rows by replicating the non-repeated columns for each\n" +
                "repeated item value. This is what we did in the previous slide.\n" +
                "• The two-table approach: split the repeating and non-repeating data into separate tables (Non-loss\n" +
                "Decomposition)\n" +
                "– We must then choose a primary key for the repeating data table\n" +
                "– …and insert this as a foreign key in the non-repeating data table\n" +
                "• The two-table approach is often better as it takes up less space and leads us to 2nd Normal Form\n" +
                "• First, other problems with 1NF Problems with a 1NF Relation: Update\n" +
                "Anomalies\n" +
                "12\n" +
                "• Such repetition means that updates can be difficult.\n" +
                "• Suppose that Smith goes on to a new grade.\n" +
                "– Changes would be required to all records for Smith.\n" +
                "– (And there is a danger that we may miss some.)\n" +
                "• Suppose that the salary for grade 2.7 is changed.\n" +
                "– All records for all staff members on grade 2.7 would have to be changed.\n" +
                "• A fact should be stored only once. Updates are then problem-free.\n" +
                "• This example relation is poorly structured, being subject to update anomalies." +
                "A relation is in Second Normal Form (2NF) if\n" +
                "– it is in 1NF and\n" +
                "– every non-key column is fully FD (FFD) on the primary key.\n" +
                "• The relation StaffBorrower is not in 2NF. Why not?\n" +
                "– Because a non-key column (such as Sname) is not fully FD on the primary key (Sno,Bno • We can achieve 2NF by splitting our 1NF into two or more relations in 2NF. " +
                "" +
                "Third Normal Form\n" +
                "27 Sno Sname Sdept Grade\n" +
                "1 Smith Computing 2.7\n" +
                "StaffBorrower3\n" +
                "Grade Salary\n" +
                "2.7 26813\n" +
                "PayScale\n" +
                "• A relation is in Third Normal Form (3NF) if\n" +
                "– it is in 1NF + 2NF and\n" +
                "– every non-key column is non-transitively fully FD on the primary key.\n" +
                "• We can always find a decomposition into 3NF.\n" +
                "• In our decomposition above, the Loan relation is already in 3NF:\n" +
                "– the only non-key column is Date_out\n" +
                "– the primary key is (Sno,Bno), and (Sno,Bno) → Date_out (i.e. FFD)\n" +
                "• But (as we have seen) StaffBorrower2 is not in 3NF.\n" +
                "• It is easy to see what to do ", "learn more about transforming ER\n" +
                "data models into relational designs.\n" +
                "• To turn customer’s requirements into\n" +
                "well-formed relations by undergoing\n" +
                "data normalisation.",    sdf3.format(new Timestamp(System.currentTimeMillis())), 3);




        dbManager.insertCourse( "Relational Algebra", "Declarative versus Procedural\n" +
                "• Theoretical background\n" +
                "• Practical context of data analytics / ‘big data’ (Python and R)\n" +
                "• Choices are not always clear\n" +
                "• There are often no ‘right’ answers\n" +
                "• Confusingly there are procedural elements within RDBMS\n" +
                "• SQL/PSM (Persistent Stored Modules)\n" +
                "• PL/SQL (Oracle), PL/pgSQL (PostreQSL), T-SQL (MS SQL Server)" +
                "" +
                "Declarative versus Procedural\n" +
                "• Theoretical background\n" +
                "• Practical context of data analytics / ‘big data’ (Python and R)\n" +
                "• Choices are not always clear\n" +
                "• There are often no ‘right’ answers\n" +
                "• Confusingly there are procedural elements within RDBMS\n" +
                "• SQL/PSM (Persistent Stored Modules)\n" +
                "• PL/SQL (Oracle), PL/pgSQL (PostreQSL), T-SQL (MS SQL Server)" +
                "" +
                "Relational Algebra\n" +
                "• the source of SQL’s flexibility/power\n" +
                "RDBMS – based on tables (‘relations’ and ‘tuples’ in them) which\n" +
                "adhere to an algebraic structure that allows reasoning and\n" +
                "manipulation independent of the physical data representation\n" +
                "• supports set manipulation\n" +
                "• follows well defined rules\n" +
                "• allows for simplification and optimisation" +
                "" +
                "Relational Algebra\n" +
                "• Sometimes remembering that any SQL query must conform to the\n" +
                "basic rules of relational algebra can be useful in trying to breakdown the purpose/structure of some (apparently) complex query\n" +
                "that you might come across\n" +
                "• In particular, the closure property of relational algebra mean that\n" +
                "we can ‘chain’ operations together (nested / correlated queries)", "RDBMS – based on tables (‘relations’ and ‘tuples’ in them) which\n" +
                "adhere to an algebraic structure that allows reasoning and\n" +
                "manipulation independent of the physical data representation",    sdf3.format(new Timestamp(System.currentTimeMillis())), 3);



        dbManager.insertCourse( "Procedural Extensions", "SQL/PSM (Persistent Stored Modules)\n" +
                "• A little bit of history\n" +
                "• Structure and ‘mechanics’ of PSM\n" +
                "• Procedure ‘blocks’ (implicit and explicit structures)\n" +
                "• structure\n" +
                "• declaration and assignment\n" +
                "• control structures\n" +
                "• cursors\n" +
                "• exceptions\n" +
                "• procedures/functions/packages\n" +
                "• triggers\n" +
                "• PL/SQL (Oracle’s implementation of PSM)" +
                "" +
                "SQL/PSM (Persistent Stored Modules)\n" +
                "• Procedure ‘blocks’\n" +
                "• structure\n" +
                "• declaration and assignment\n" +
                "• control structures\n" +
                "• cursors\n" +
                "• exceptions\n" +
                "• procedures/functions/packages\n" +
                "• triggers" +
                "" +
                "PL/SQL – basic structure\n" +
                "• Similar features to many imperative (‘high level’) programming\n" +
                "languages: variables, constants, control structures, exception\n" +
                "handling, modular code\n" +
                "• Basic units: un-named ‘blocks’ (named: procedures and functions)\n" +
                "• PL/SQL block [DECLARE Optional\n" +
                "{list of declarations} ]\n" +
                "BEGIN Mandatory\n" +
                "{executable statements}\n" +
                "[EXCEPTION Optional\n" +
                "{code to handle exceptions} ]\n" +
                "END; Mandatory" +
                "" +
                "PL/SQL – Declarations\n" +
                "• Variables and constants must be declared before reference\n" +
                "• If a variable is declared as ‘NOT NULL’ a value must be assigned\n" +
                "• Can declare variables to be same type as a column in a table\n" +
                "• or even define a variable to incorporate columns of an entire tuple\n" +
                "vStudentNo VARCHAR2(5);\n" +
                "vAge NUMBER(4,1) NOT NULL := 18;\n" +
                "Max_Classes CONSTANT NUMBER := 50;\n" +
                "vStudentNo Student.std_ID%TYPE;\n" +
                "vStudentRec Student%ROWTYPE;\n" +
                "%TYPE and %ROWTYPE – not standard SQL/PSM ", "• Sometimes ‘declarative’ is not enough",    sdf3.format(new Timestamp(System.currentTimeMillis())), 4);


        dbManager.insertCourse( "NoSQL and 'post-relational' trends" , "Confusion around “NoSQL”\n" +
                "• Most commonly stands for “Not Only SQL”\n" +
                "• Perhaps more useful to think of as post-relational databases\n" +
                "• Multiple alternate types of NoSQL database exist\n" +
                "• key-value / column / document / graph or RDF (+ multi-model)\n" +
                "• There are effectively no (or very limited) standards\n" +
                "• except some for querying (which look a lot like SQL!!)  " +
                "" +
                "Types of NoSQL Database\n" +
                "• Key-Value stores\n" +
                "• Columnar stores\n" +
                "• Document databases\n" +
                "• Graph databases", "Almost two decades of ‘post-relational’ (NoSQL) database evolution\n" +
                "and still few agreed-upon definitions!",    sdf3.format(new Timestamp(System.currentTimeMillis())), 4);




//        dbManager.insertNotification(1, "sample message subcription", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample1");
//        dbManager.insertNotification(1, "Subscription User major", sdf3.format(new Timestamp(System.currentTimeMillis())), "sample2");
//        dbManager.insertNotification(1, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
//        dbManager.insertNotification(2, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
//        dbManager.insertNotification(3, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
//
//        dbManager.insertShelf(1, 1, 0);
//        dbManager.insertShelf(1, 2, 0);
//        dbManager.insertShelf(1, 3, 0);
//        dbManager.insertShelf(1, 4, 1);
//        dbManager.insertShelf(1, 5, 0);
//        dbManager.insertShelf(1, 6, 1);
//        dbManager.insertShelf(2, 3, 0);
//        dbManager.insertShelf(3, 5, 0);
//
//        dbManager.insertGroup("Group Sample", "This is a sample group", "5e0cfa202fb14f31920be025e99ed084");
//        dbManager.insertGroup("Group Sample1", "This is a sample group", "4465f751acbe4ca6b3118221a7e83935");
//
//        dbManager.insertGroupMember("1", "1");
//        dbManager.insertGroupMember("2", "1");
//        dbManager.insertGroupMember("3", "1");
//        dbManager.insertGroupMember("4", "1");
//        dbManager.insertGroupMember("5", "1");
//        dbManager.insertGroupMember("6", "2");
//        dbManager.insertGroupMember("3", "2");
//        dbManager.insertGroupMember("2", "2");
//
//
//        dbManager.insertScore(3, 6, 60);

//        dbManager.insertOtp(2, 40000);
    }
}