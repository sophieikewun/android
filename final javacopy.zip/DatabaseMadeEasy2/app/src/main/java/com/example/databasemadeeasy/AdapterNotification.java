package com.example.databasemadeeasy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterNotification extends RecyclerView.Adapter<AdapterNotification.MyViewHolder> {
    private Context context;
    ArrayList<String> notificationIdList, notificationMessageList, notificationTitleList, notificationTimestampList;


    AdapterNotification(Context context, ArrayList notificationIdList, ArrayList notificationMessageList, ArrayList notificationTitleList, ArrayList notificationTimestampList){
        this.context = context;
        this.notificationIdList = notificationIdList;
        this.notificationMessageList = notificationMessageList;
        this.notificationTitleList = notificationTitleList;
        this.notificationTimestampList = notificationTimestampList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_notification, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
//        ImageView notificationDetailBtn;
//        TextView notificationTitle, notificationTimestamp;
//        LinearLayout notificationMainLayout;

        holder.notificationTitle.setText(String.valueOf(notificationTitleList.get(position)));
        holder.notificationTimestamp.setText(String.valueOf(notificationTimestampList.get(position)));

        holder.notificationMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, NotificationDetails.class);
                intent.putExtra("notificationId", String.valueOf(notificationIdList.get(position)));
                intent.putExtra("notificationMessage", String.valueOf(notificationMessageList.get(position)));
                intent.putExtra("notificationTitle", String.valueOf(notificationTitleList.get(position)));
                intent.putExtra("notificationTimestamp", String.valueOf(notificationTimestampList.get(position)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.notificationIdList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView notificationDetailBtn;
        TextView notificationTitle, notificationTimestamp;
        LinearLayout notificationMainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            notificationDetailBtn = itemView.findViewById(R.id.notificationDetailBtn);
            notificationTitle = itemView.findViewById(R.id.notificationTitle);
            notificationTimestamp = itemView.findViewById(R.id.notificationTimestamp);
            notificationMainLayout = itemView.findViewById(R.id.notificationMainLayout);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
