package com.example.databasemadeeasy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.example.databasemadeeasy.QuizContract.*;

import java.util.ArrayList;
import java.util.List;

public class DBManager {
    DBHelper dbHelper;
    Context context;
    SQLiteDatabase sqLiteDatabaseWriter;
    SQLiteDatabase sqLiteDatabaseReader;
    private static DBManager instance;

    public DBManager(Context context) {
        this.context = context;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DBHelper(context);
        sqLiteDatabaseWriter = dbHelper.getWritableDatabase();
        sqLiteDatabaseReader = dbHelper.getReadableDatabase();
        return this;
    }

    public static synchronized DBManager getInstance(Context context) {
        if (instance == null) {
            instance = new DBManager(context.getApplicationContext());
        }
        return instance;
    }

    public void close() {
        dbHelper.close();
    }


    // Insert Statement

    public void insertScore(int userId, int courseId, int score) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("score", score);
        long result = sqLiteDatabaseWriter.insert("score", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertCategory(String categoryName) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("categoryName", categoryName);
        long result = sqLiteDatabaseWriter.insert("category", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public long insertUser(String fullName, String email, String password, int role, int activated) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("fullName", fullName);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("role", role);
        contentValues.put("activated", activated);
        long result = sqLiteDatabaseWriter.insert("user", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

        return result;
    }

    public void insertCourse(String courseName, String description, String excerpt, String lastModified, int categoryId) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("courseName", courseName);
        contentValues.put("description", description);
        contentValues.put("excerpt", excerpt);
        contentValues.put("lastModified", lastModified);
        contentValues.put("categoryId", categoryId);
        long result = sqLiteDatabaseWriter.insert("course", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertShelf(int userId, int courseId, int completed) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("completed", completed);
        long result = sqLiteDatabaseWriter.insert("shelf", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

//   public void insertTestScore(int userId, int questionId) {
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("userId", userId);
//        contentValues.put("questionId", questionId);
//        long result = sqLiteDatabaseWriter.insert("testScore", null, contentValues);
//        if (result == -1) {
//            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
//        } else {
//            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
//        }
//    }

    public void insertOtp(long userId, int otp_code, String timeToExpire) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("otp_code", otp_code);
        contentValues.put("timeToExpire", timeToExpire);
        long result = sqLiteDatabaseWriter.insert("otp", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success OTP", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertNotification(int userId, String message, String timestamp, String title) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("message", message);
        contentValues.put("timestamp", timestamp);
        contentValues.put("title", title);
        long result = sqLiteDatabaseWriter.insert("notification", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public long insertGroup(String title, String description, String link) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("description", description);
        contentValues.put("link", link);
        long result = sqLiteDatabaseWriter.insert("groups", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    public void insertGroupMember(String userId, String groupsId) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("groupsId", groupsId);
        long result = sqLiteDatabaseWriter.insert("groupmembers", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor fetchGroupMembers(String groupId) {
        String query = "Select fullname from user where userId in (Select userId from groupmembers where groupsId = " + '"' + groupId + '"' + ");";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchGroupMemberAvailability(String groupId, String userId) {
        String query = "Select * from groupmembers where groupsId = " + '"' + groupId + '"' + "  AND userId = " + '"' + userId + '"';

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchGroupMemberGroups(String userId) {
        String query = "Select * from groups where groupId in (Select groupsId from groupmembers where userId = " + '"' + userId + '"' + ");";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }


    public void updateUserPassword(String user_id, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("password", password);

        int query = sqLiteDatabaseWriter.update("user", contentValues, "userId" + " = " + user_id, null);

        if (query == -1) {
            Toast.makeText(context, "Password failed to update ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Password updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    public void updateUserActivation(String user_id, int activation_value) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("activated", activation_value);

        int query = sqLiteDatabaseWriter.update("user", contentValues, "userId" + " = " + user_id, null);

        if (query == -1) {
            Toast.makeText(context, "Account failed to update ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Account updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor fetchAllData(String tableName) {

        String query = "Select * from " + tableName;

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataById(String tableName, String id, String tableColumn) {
        String query = "Select * from " + tableName + " where " + '"' + tableColumn + '"' + " = " + "'" + id + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataBySpecificColumn(String tableName, String columnValue, String tableColumn) {
        String query = "Select * from " + tableName + " where " + tableColumn + " = " + "'" + columnValue + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchCourseStudentDetail(int courseId) {
        String query = "Select count(courseId) from shelf where courseId = " + '"' + courseId + '"';

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchShelfData(String shelfType, String userId) {
       //fillQuestionTable();

        String query = "Select c.courseId, c.courseName, c.lastModified, c.categoryId from course c where courseId in (select courseId from shelf where userId = " + "'" + userId + "' AND completed = " + "'" + shelfType + "');";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchCourseStudentEnrolled(String userId, String courseId) {
        String query = "Select * from shelf where userId = " + "'" + userId + "' AND courseId = " + "'" + courseId + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchPopularCourse() {
        String query = "select * from course where courseId in (select courseId from shelf group by courseId order by count(*) desc LIMIT 4);";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchOtpCode(String userId) {
        String query = "select otp_code, timeToExpire from otp where userId = " + "'" + userId + "' order by otpId DESC LIMIT 1;";
//        String query = "select * from otp where userId = " + userId +  " order by otpId DESC LIMIT 1;";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    private void fillCategoriesTable() {
        Category c1 = new Category("Beginner");
        addCategory(c1);
        Category c2 = new Category("Intermediate");
        addCategory(c2);
        Category c3 = new Category("Advanced");
        addCategory(c3);
        Category c4 = new Category("Expert");
        addCategory(c4);
    }

    private void fillQuestionTable() {
        Toast.makeText(context.getApplicationContext(), "Fill ques", Toast.LENGTH_SHORT).show();
        Question q1 = new Question("who is the president", "A", "B", "c", 1, 1);
        insertQuestion(q1);
        Question q2 = new Question("eho is sophia", "A", "B", "c", 2, 1);
        insertQuestion(q2);
        Question q3 = new Question("how re uou", "A", "B", "c", 3, 1);
        insertQuestion(q3);
        Question q4 = new Question("God is good ", "A", "B", "c", 1, 1);
        insertQuestion(q4);
        Question q5 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 1);
        insertQuestion(q5);
        Question q6 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q6);
        Question q7 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q7);
        Question q8 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q8);
        Question q9 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q9);
        Question q10 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q10);
        Question q11 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q11);
        Question q12 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q12);
        Question q13 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q13);
        Question q14 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q14);
        Question q15 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q15);
        Question q16 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q16);
        Question q17 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q17);
        Question q18 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q18);
        Question q19 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q19);
        Question q20 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q20);
    }
    private void addCategory(Category category) {
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, category.getName());
        sqLiteDatabaseWriter.insert(CategoriesTable.TABLE_NAME, null, cv);
    }


    public void addQuestion(Question question) {
        insertQuestion(question);
    }

    public void addQuestions(List<Question> questions){
        for (Question question : questions){
            insertQuestion(question);
        }
    }

    private void insertQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionTable.COLUMN_CATEGORY_ID, question.getCategoryID());
        sqLiteDatabaseWriter.insert(QuestionTable.TABLE_NAME, null, cv);

    }

    public List<Category> getAllCategories(){
        List<Category> categoryList = new ArrayList<>();
        String query = "SELECT * FROM " + '"' + "category" + '"' + ";";

        System.out.println(query);
        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        if(cursor != null) {
            while(cursor.moveToNext()) {
                    Category category = new Category();
                    category.setId(cursor.getInt(0));
                    category.setName(cursor.getString(1));
                    categoryList.add(category);
            }
        }


        return categoryList;
    }

    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionList = new ArrayList<>();
        Cursor c = sqLiteDatabaseReader.rawQuery(" SELECT * FROM " + QuestionTable.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(0));
                question.setQuestion(c.getString(1));
                question.setOption1(c.getString(2));
                question.setOption2(c.getString(3));
                question.setOption3(c.getString(4));
                question.setAnswerNr(c.getInt(5));
                question.setCategoryID(c.getInt(6));
                questionList.add(question);

            } while (c.moveToNext());

        }
        c.close();
        return questionList;
    }

    public ArrayList<Question> getQuestions(int categoryID) {
        ArrayList<Question> questionList = new ArrayList<>();
        String selection = QuestionTable.COLUMN_CATEGORY_ID + " = ? ";

        String[] selectionArgs = new String[]{String.valueOf(categoryID)};

        Cursor c = sqLiteDatabaseReader.query(
                QuestionTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(0));
                question.setQuestion(c.getString(1));
                question.setOption1(c.getString(2));
                question.setOption2(c.getString(3));
                question.setOption3(c.getString(4));
                question.setAnswerNr(c.getInt(5));
                question.setCategoryID(c.getInt(6));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }


}
