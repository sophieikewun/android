package com.example.databasemadeeasy;

import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.gridlayout.widget.GridLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class ShelfProgress extends Fragment {

    GridLayout courseGrid;
    Button searchBtn;
    DBManager dbManager;
    ArrayList<String> courseId, courseName;

    RecyclerView courseShelfProgRecycler;
    ShelfAdapter shelfAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shelf_progress, container, false);


        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        courseShelfProgRecycler = view.findViewById(R.id.courseShelfProgRecycler);

        dbManager = new DBManager(getContext());


        storeDataInArrays();

        shelfAdapter = new ShelfAdapter(view.getContext(), courseId, courseName);

        GridLayoutManager layoutManager = new GridLayoutManager(view.getContext(),1);


        courseShelfProgRecycler.setAdapter(shelfAdapter);
        courseShelfProgRecycler.setLayoutManager(layoutManager);
        // Inflate the layout for this fragment

        return view;
    }

    void storeDataInArrays() {
        DBManager dbManager = new DBManager(getContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchShelfData("0", "1");

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
            }
        }
    }
}