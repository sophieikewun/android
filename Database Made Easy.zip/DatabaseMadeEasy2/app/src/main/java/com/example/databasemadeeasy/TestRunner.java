package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.airbnb.paris.Paris;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class TestRunner extends AppCompatActivity {
    Button ssBtn, button2;
    EditText message, userId, fullName, email, password;

    ArrayList<String> courseId, courseName, excerpt;

    RecyclerView courseMainRecycler;
    CourseMainAdapter courseMainAdapter;
    private static final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_runner);
        ssBtn = findViewById(R.id.ssBtn);
        message = findViewById(R.id.message);
        userId = findViewById(R.id.userId);
        fullName = findViewById(R.id.fullname);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        button2 = findViewById(R.id.button2);

        courseMainRecycler = findViewById(R.id.courseMainRecycler);

        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        excerpt = new ArrayList<>();

        ssBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                notifications(message.getText().toString(), Integer.parseInt(userId.getText().toString()), sdf3.format(timestamp) );
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user(fullName.getText().toString(), email.getText().toString(), password.getText().toString(), 0);
            }
        });



//        dataAllFetcher("user");
//        dataAllFetcher("course");
//        dataAllFetcher("otp");
//        dataAllFetcher("score");
//        dataAllFetcher("notification");
//        dataAllFetcher("shelf");

//        dataSpecificEmailFetcher("user", "email", "email");
//        dataSpecificEmailFetcher("user", "sampleuser@mail.com", "email");
//        dataSpecificEmailFetcher("user", "password", "password");

        storeDataInArrays();

        courseMainAdapter = new CourseMainAdapter(this, courseId, courseName, excerpt);
//        courseMainAdapter = new CourseMainAdapter(TestRunner.this, this, courseId, courseName, excerpt);

        GridLayoutManager layoutManager = new GridLayoutManager(this,2);


        courseMainRecycler.setAdapter(courseMainAdapter);
        courseMainRecycler.setLayoutManager(layoutManager);

    }

    public void notifications(String message, int userId, String timestamp) {

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();
        dbManager.insertNotification(userId, message, timestamp);
    }

    public void user(String fullName, String email, String password, int role) {

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

//        dbManager.insertUser(fullName, email, password, role);

        dbManager.insertUser("Sample user", "sampleuser@mail.com", "samplee", 0);
        dbManager.insertUser("fullName", "email", "password", 0);

        dbManager.insertCourse("Database for dummy", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertNotification(2, "sample message", "tyghb");
        dbManager.insertShelf(1, 1, 0);
        dbManager.insertScore(3, 2, 60);
        dbManager.insertOtp(2, 40000);
    }

    public void dataAllFetcher(String tableName) {
        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchAllData(tableName);

        System.out.println(tableName + ": " + cursor.getCount());
    }

    public void dataSpecificEmailFetcher(String tableName, String columnValue, String tableColumn) {
        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchDataBySpecificColumn(tableName, columnValue, tableColumn);

//        System.out.println(cursor.getCount());
//        while (cursor.moveToNext()) {
//            System.out.println(cursor.getString(0));
//            System.out.println(cursor.getString(1));
//            System.out.println(cursor.getString(2));
//            System.out.println(cursor.getString(3));
//            System.out.println();
//        }
    }


    void storeDataInArrays() {
        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchAllData("course");
        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                excerpt.add(cursor.getString(3));
            }
        }
    }

}