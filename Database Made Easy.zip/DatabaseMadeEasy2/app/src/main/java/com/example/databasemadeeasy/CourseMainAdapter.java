package com.example.databasemadeeasy;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CourseMainAdapter extends RecyclerView.Adapter<CourseMainAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    ArrayList<String> courseId, courseName, excerpt;

//    CourseMainAdapter(Activity activity, Context context, ArrayList courseId, ArrayList courseName, ArrayList excerpt){
//    CourseMainAdapter(Activity activity, Context context, ArrayList courseId, ArrayList courseName, ArrayList excerpt){
    CourseMainAdapter(Context context, ArrayList courseId, ArrayList courseName, ArrayList excerpt){
//        this.activity = activity;
        this.context = context;
        this.courseId = courseId;
        this.courseName = courseName;
        this.excerpt = excerpt;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_course, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.courseMainTitle.setText(String.valueOf(courseName.get(position)));
        holder.courseMainExcerpt.setText(String.valueOf(excerpt.get(position)));
        //Recyclerview onClickListener
        holder.courseMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Course_details.class);
                intent.putExtra("courseId", String.valueOf(courseId.get(position)));
                intent.putExtra("courseName", String.valueOf(courseName.get(position)));
                intent.putExtra("courseExcerpt", String.valueOf(excerpt.get(position)));
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return this.courseId.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView courseMainTitle, courseMainExcerpt;
        LinearLayout courseMainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            courseMainTitle = itemView.findViewById(R.id.courseMainTitle);
            courseMainExcerpt = itemView.findViewById(R.id.courseMainExcerpt);
            courseMainLayout = itemView.findViewById(R.id.courseMainLayout);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
