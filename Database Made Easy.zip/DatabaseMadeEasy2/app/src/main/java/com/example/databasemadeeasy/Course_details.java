package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Course_details extends AppCompatActivity {

    ImageView backCourseDetailBtn, courseDetailShelfBtn;
    TextView courseDetailExcerpt, courseDetailTitle, courseDetailDate, courseDetailStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        backCourseDetailBtn = findViewById(R.id.backCourseDetailBtn);
        courseDetailShelfBtn = findViewById(R.id.courseDetailShelfBtn);
        courseDetailExcerpt = findViewById(R.id.courseDetailExcerpt);
        courseDetailTitle = findViewById(R.id.courseDetailTitle);
        courseDetailDate = findViewById(R.id.courseDetailDate);
        courseDetailStudent = findViewById(R.id.courseDetailStudent);

        Bundle bundle = getIntent().getExtras();

        courseDetailExcerpt.setText(bundle.getString("courseExcerpt"));
        courseDetailTitle.setText(bundle.getString("courseName"));

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();
        Cursor cursor = dbManager.fetchCourseStudentDetail(Integer.parseInt(bundle.getString("courseId")));

        if(cursor.getCount() == 0) {
            courseDetailStudent.setText(0);
        }
        else {
            while(cursor.moveToNext()) {
                courseDetailStudent.setText(cursor.getString(0));
            }
        }




        backCourseDetailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        courseDetailShelfBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), myshelf.class));
            }
        });

    }
}