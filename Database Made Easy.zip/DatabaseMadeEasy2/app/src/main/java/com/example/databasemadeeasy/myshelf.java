package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.airbnb.paris.Paris;

public class myshelf extends AppCompatActivity {

    ImageView shelfBackBtn;
    Button onGoingBtn, completedBtn;
    FragmentContainerView fragmentContainerView;
    FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myshelf);

        shelfBackBtn = findViewById(R.id.shelfBackBtn);
        onGoingBtn = findViewById(R.id.onGoingBtn);
        completedBtn = findViewById(R.id.completedBtn);

        fm = getSupportFragmentManager();
        fragmentContainerView = findViewById(R.id.fragmentContainerView3);


        shelfBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        onGoingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                        cc();

                Paris.style(onGoingBtn).apply(R.style.shelfActive);
                Paris.style(completedBtn).apply(R.style.shelfInactive);

                fm.beginTransaction()
                        .replace(R.id.fragmentContainerView3, ShelfProgress.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();
            }
        });

        completedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Paris.style(completedBtn).apply(R.style.shelfActive);
                Paris.style(onGoingBtn).apply(R.style.shelfInactive);

                fm.beginTransaction()
                        .replace(R.id.fragmentContainerView3, ShelfCompleted.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();
            }
        });
    }

    public void cc() {

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

//        dbManager.insertUser(fullName, email, password, role);

        dbManager.insertUser("Sample user", "sampleuser@mail.com", "samplee", 0);
        dbManager.insertUser("Sophia Ikewun", "sophiaikewun@mail.com", "samplee", 0);
        dbManager.insertUser("Ikewun Zoe", "ikewunzoe@mail.com", "samplee", 0);

        dbManager.insertCourse("Database for dummy", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("Fundamentals of database", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("Advances in database operations", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("College Database", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("Variables Data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("Machine learning data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");

        dbManager.insertCourse("Sample Data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample");




        dbManager.insertNotification(2, "sample message", "tyghb");
        dbManager.insertNotification(2, "User major", "tyghb");
        dbManager.insertNotification(2, "Creative", "tyghb");

        dbManager.insertShelf(1, 1, 0);
        dbManager.insertShelf(1, 2, 0);
        dbManager.insertShelf(1, 3, 0);
        dbManager.insertShelf(1, 4, 1);
        dbManager.insertShelf(1, 5, 0);
        dbManager.insertShelf(1, 6, 1);

        dbManager.insertShelf(2, 3, 0);
        dbManager.insertShelf(3, 5, 0);

        dbManager.insertScore(3, 6, 60);
        dbManager.insertOtp(2, 40000);
    }
}