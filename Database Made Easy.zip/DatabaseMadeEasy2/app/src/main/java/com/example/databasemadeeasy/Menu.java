package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Menu extends AppCompatActivity {
    ImageView closeNav;
    TextView shelfNav, categoriesNav, groupsNav, assessmentNav, certificationNav, homeNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        closeNav = findViewById(R.id.closeNav);

        homeNav = findViewById(R.id.homeNav);
        shelfNav = findViewById(R.id.shelfNav);
        categoriesNav = findViewById(R.id.categoriesNav);
        groupsNav = findViewById(R.id.groupsNav);
        assessmentNav = findViewById(R.id.assessmentNav);
        certificationNav = findViewById(R.id.certificationNav);

        closeNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        homeNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Base_page.class));
            }
        });
        shelfNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), myshelf.class));
            }
        });
        categoriesNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Base_page.class));
            }
        });
        groupsNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), myshelf.class));
            }
        });
        assessmentNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Base_page.class));
            }
        });
        certificationNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Base_page.class));
            }
        });


    }
}