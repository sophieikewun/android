package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Base_page extends AppCompatActivity {
    ImageView homeFrag, courseFrag, notificationFrag, profileFrag, navID;

    FragmentContainerView fragmentContainerView;
    FragmentManager fm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_page);

        homeFrag = findViewById(R.id.homeFrag);
        courseFrag = findViewById(R.id.courseFrag);
        notificationFrag = findViewById(R.id.notificationFrag);
        profileFrag = findViewById(R.id.profileFrag);
        navID = findViewById(R.id.navID);
        fragmentContainerView = findViewById(R.id.fragmentContainerView);
        fm = getSupportFragmentManager();

        homeFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(explore.class);
            }
        });
        courseFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Courses.class);
            }
        });
        notificationFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Notificatrion.class);
            }
        });
        profileFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Profile.class);
            }
        });
        navID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Menu.class));
            }
        });




//        FragmentTransaction transaction = fm.beginTransaction();
//        transaction.replace(R.id.fragmentContainerView, Courses.class, null);
//        transaction.commit();
//
//        fragmentContainerView

    }

    public void switchPage(Class className) {
        fm.beginTransaction()
                .replace(R.id.fragmentContainerView, className, null)
                .setReorderingAllowed(true)
                .addToBackStack("name")
                .commit();
    }
}