package com.example.databasemadeeasy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class DBManager {
    DBHelper dbHelper;
    Context context;
    SQLiteDatabase sqLiteDatabaseWriter;
    SQLiteDatabase sqLiteDatabaseReader;

    public DBManager(Context context) {
        this.context = context;
    }

    public DBManager open() throws SQLException{
        dbHelper = new DBHelper(context);
        sqLiteDatabaseWriter = dbHelper.getWritableDatabase();
        sqLiteDatabaseReader = dbHelper.getReadableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }


    // Insert Statement

    public void insertScore(int userId, int courseId, int score) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("score", score);
        long result = sqLiteDatabaseWriter.insert("score", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertUser(String fullName, String email, String password, int role) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("fullName", fullName);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("role", role);
        long result = sqLiteDatabaseWriter.insert("user", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertCourse(String courseName, String description, String excerpt) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("courseName", courseName);
        contentValues.put("description", description);
        contentValues.put("excerpt", excerpt);
        long result = sqLiteDatabaseWriter.insert("course", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertShelf(int userId, int courseId, int completed) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("completed", completed);
        long result = sqLiteDatabaseWriter.insert("shelf", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertOtp(int userId, int otp_code) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("otp_code", otp_code);
        long result = sqLiteDatabaseWriter.insert("otp", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertNotification(int userId, String message, String timestamp) {
        sqLiteDatabaseWriter.execSQL("DELETE FROM notification");
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("message", message);
        contentValues.put("timestamp", timestamp);
        long result = sqLiteDatabaseWriter.insert("notification", null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public Cursor fetchAllData(String tableName) {
        String query = "Select * from "  + tableName;

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataById(String tableName, long id, String tableColumn) {
        String query = "Select * from "  + tableName + " where " + '"' + tableColumn + '"' + " = " + '"' + id + '"';

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataBySpecificColumn(String tableName, String columnValue, String tableColumn) {
        String query = "Select * from "  + tableName + " where " +  tableColumn + " = " + "'" + columnValue + "'";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchCourseStudentDetail(int courseId) {
        String query = "Select count(courseId) from shelf where courseId = " + '"' + courseId + '"' ;

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchShelfData(String shelfType, String userId) {
        String query = "Select c.courseId, c.courseName from course c, user u, shelf s where s.userId = " + "'" +  userId + "' AND s.completed = " + "'" + shelfType + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }



}
