package com.example.databasemadeeasy;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(@Nullable Context context) {
        super(context, "DBForDummies", null, 1);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String user = "CREATE TABLE user (userId integer primary key autoincrement, fullname text not null, email text not null unique, password text not null, role integer not null default 0);";

        String otp = "CREATE TABLE otp (otpId integer primary key autoincrement, otp_code integer not null, userId integer not null, constraint fk_otp_userid foreign key(userId) references user(userId));";

        String course = "CREATE TABLE course (courseId integer primary key autoincrement, courseName text not null, description text not null, excerpt text not null);";

        String score = "CREATE TABLE score (scoreId integer primary key autoincrement, userId integer not null, courseId integer not null, score integer not null, constraint fk_score_userid foreign key(userId) references user(userId), constraint fk_score_courseid foreign key(courseId) references course(courseId));";

        String shelf = "CREATE TABLE shelf(shelfId integer primary key autoincrement, userId integer not null, courseId integer not null, completed integer not null default 0, constraint fk_shelf_userid foreign key(userId) references user(userId), constraint fk_shelf_courseid foreign key(courseId) references course(courseId));";

        String notification = "CREATE TABLE notification(notificationId integer primary key autoincrement, userId integer not null, message text not null, timestamp text not null, constraint fk_notification_userid foreign key(userId) references user(userId));";

        db.execSQL(user);
        db.execSQL(otp);
        db.execSQL(course);
        db.execSQL(score);
        db.execSQL(shelf);
        db.execSQL(notification);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS otp");
        db.execSQL("DROP TABLE IF EXISTS course");
        db.execSQL("DROP TABLE IF EXISTS score");
        db.execSQL("DROP TABLE IF EXISTS shelf");
        db.execSQL("DROP TABLE IF EXISTS notification");

        onCreate(db);
    }
}
