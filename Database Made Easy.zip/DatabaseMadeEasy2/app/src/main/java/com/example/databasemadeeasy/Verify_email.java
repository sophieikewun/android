package com.example.databasemadeeasy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.method.NumberKeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Verify_email extends AppCompatActivity {

    ImageView backBtn;
    Button verifyBtn;
    EditText otp1, otp2, otp3, otp4, otp5;
    TextView emailId, messageBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_email);

        backBtn = findViewById(R.id.backBtn);
        verifyBtn = findViewById(R.id.verifyBtn);
        otp1 = findViewById(R.id.otp1);
        otp2 = findViewById(R.id.otp2);
        otp3 = findViewById(R.id.otp3);
        otp4 = findViewById(R.id.otp4);
        otp5 = findViewById(R.id.otp5);
        emailId = findViewById(R.id.emailId);
        messageBox = findViewById(R.id.messageBox3);


        Bundle extras = getIntent().getExtras();
        String emailAddress = extras.getString("email");

        emailId.setText(emailAddress);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otp1Value = otp1.getText().toString();
                String otp2Value = otp2.getText().toString();
                String otp3Value = otp3.getText().toString();
                String otp4Value = otp4.getText().toString();
                String otp5Value = otp5.getText().toString();

                if (otp1Value.isEmpty() || otp2Value.isEmpty() || otp3Value.isEmpty() || otp4Value.isEmpty() || otp5Value.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    int otp = Integer.parseInt(otp1Value + otp2Value + otp3Value + otp4Value + otp5Value);

                    if(otp == 11111) {
                        startActivity(new Intent(getApplicationContext(), Account_created.class));
                    }
                    else {
                        setMessageBox("Incorrect OTP Code");
                    }
                }
            }
        });

        Number[] value = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57};

        otp1.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp2.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp2.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp3.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp3.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp4.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp4.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp5.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }
}