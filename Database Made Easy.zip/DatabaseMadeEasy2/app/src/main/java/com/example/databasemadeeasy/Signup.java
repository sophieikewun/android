package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Signup extends AppCompatActivity {

    ImageView backBtn;
    Button signupBtn, loginBtn;
    EditText emailField, passwordField, fullNameField;
    TextView forgotPwdBtn, messageBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        backBtn = findViewById(R.id.backBtn);
        signupBtn = findViewById(R.id.verifyBtn);
        loginBtn = findViewById(R.id.signInBtn);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        fullNameField = findViewById(R.id.fullNameField);
        forgotPwdBtn = findViewById(R.id.forgotPwdBtn);
        messageBox = findViewById(R.id.messageBox2);



        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Main_login.class));
            }
        });

        forgotPwdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Password_reset.class));
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailValue = emailField.getText().toString();
                String passwordValue = passwordField.getText().toString();
                String fullNameValue = fullNameField.getText().toString();

                if(emailValue.isEmpty() || passwordValue.isEmpty() || fullNameValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    Intent i = new Intent(v.getContext(), Verify_email.class);
                    i.putExtra("email", emailValue);
                    emailField.setText("");
                    passwordField.setText("");
                    fullNameField.setText("");
                    startActivity(i);
                }
            }
        });

    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }
}