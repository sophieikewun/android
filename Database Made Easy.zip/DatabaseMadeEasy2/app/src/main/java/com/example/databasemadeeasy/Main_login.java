package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Main_login extends AppCompatActivity {

    ImageView backBtn;
    Button signupBtn, loginBtn;
    EditText emailField, passwordField;
    TextView forgotPwdBtn, messageBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);

        backBtn = findViewById(R.id.backBtn);
        signupBtn = findViewById(R.id.signInBtn);
        loginBtn = findViewById(R.id.verifyBtn);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        forgotPwdBtn = findViewById(R.id.forgotPwdBtn);
        messageBox = findViewById(R.id.messageBox);


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Signup.class));
            }
        });

        forgotPwdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Password_reset.class));
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailValue = emailField.getText().toString();
                String passwordValue = passwordField.getText().toString();

                if(emailValue.isEmpty() || passwordValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    if(emailValue.equals("sample") && passwordValue.equals("12345")) {
                        emailField.setText("");
                        passwordField.setText("");

                        startActivity(new Intent(getApplicationContext(), Base_page.class));
                    }
                    else {
                        setMessageBox("Incorrect Details");
                    }
                }
            }
        });

    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }
}