package com.example.databasemadeeasy;

import android.os.Bundle;

import androidx.core.widget.TextViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.airbnb.paris.Paris;

public class Profile extends Fragment {
    Button personalBtn, secBtn;

    FragmentContainerView fragmentContainerView;
    FragmentManager fm;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        fm = getParentFragmentManager();
        personalBtn = view.findViewById(R.id.personalBtn);
        secBtn = view.findViewById(R.id.secBtn);
        fragmentContainerView = view.findViewById(R.id.fragmentContainerView2);


        personalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Paris.style(personalBtn).apply(R.style.profileActiveSwitcher);
                Paris.style(secBtn).apply(R.style.profileInactiveSwitcher);

                fm.beginTransaction()
                        .replace(R.id.fragmentContainerView2, ProfilePersonal.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();
            }
        });

        secBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Paris.style(secBtn).apply(R.style.profileActiveSwitcher);
                Paris.style(personalBtn).apply(R.style.profileInactiveSwitcher);

                fm.beginTransaction()
                        .replace(R.id.fragmentContainerView2, ProfileSecurity.class, null)
                        .setReorderingAllowed(true)
                        .addToBackStack("name")
                        .commit();
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

}