package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.UUID;

public class Open_group extends AppCompatActivity {

    LinearLayout groupSearchLayout, groupSearchFoundLayout;
    EditText searchJoinLinkField, groupLinkBox;
    Button searchJoinBtn, groupLinkJoinBtn;
    TextView groupTitle, groupTotalCount;
    ImageView backBtn;
    Cursor cursor;
    String title, description, link, groupId, searchJoinLinkFieldValue;
    DBManager dbManager;
    SharedPreferences sharedPreferences;
    String user_id;
    RecyclerView courseCategoryMainRecycler11;

    ArrayList<String> userFullNames;
    boolean userPresent;

    int groupMemberCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_group);

        backBtn = findViewById(R.id.imageView9);
        groupSearchLayout = findViewById(R.id.groupSearchLayout);
        groupSearchFoundLayout = findViewById(R.id.groupSearchFoundLayout);
        searchJoinLinkField = findViewById(R.id.searchJoinLinkField);
        groupLinkBox = findViewById(R.id.groupLinkBox);
        searchJoinBtn = findViewById(R.id.searchJoinBtn);
        groupLinkJoinBtn = findViewById(R.id.groupLinkJoinBtn);
        groupTitle = findViewById(R.id.groupTitle);
        groupTotalCount = findViewById(R.id.groupTotalCount);
        courseCategoryMainRecycler11 = findViewById(R.id.courseCategoryMainRecycler11);

        dbManager = new DBManager(getApplicationContext());
        userFullNames = new ArrayList<>();
        userPresent = false;

        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", getApplicationContext().MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));



        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        searchJoinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchJoinLinkFieldValue = searchJoinLinkField.getText().toString();

                if(searchJoinLinkFieldValue.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    cursor = dbManager.open().fetchDataBySpecificColumn("groups", searchJoinLinkFieldValue, "link");

                    if(cursor.getCount() == 0) {
                        Toast.makeText(getApplicationContext(), "Invalid link", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        while(cursor.moveToNext()) {
                            groupId = cursor.getString(0);
                            title = cursor.getString(1);
                            description = cursor.getString(2);
                            link = cursor.getString(3);
                        }

                        searchJoinLinkField.setText("");
                        groupSearchLayout.setVisibility(View.GONE);
                        groupSearchFoundLayout.setVisibility(View.VISIBLE);

                        setGroupSearchFoundLayout();
                    }
                }
            }
        });

        groupLinkJoinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(userPresent) {
                    openGroup();
                } else {

                    if(groupMemberCount > 4) {
                        Toast.makeText(getApplicationContext(), "Group full", Toast.LENGTH_SHORT).show();
                    } else {
                        dbManager.open().insertGroupMember(user_id, groupId);
                        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        dbManager.open().insertNotification(Integer.parseInt(user_id), new NotificationMessage().joinGroupMessage(title), sdf3.format(new Timestamp(System.currentTimeMillis())), "New group joined");

                        openGroup();
                    }
                }
            }
        });

    }

    public void openGroup() {
        Intent intent = new Intent(getApplicationContext(), GroupMainPage.class);
        intent.putExtra("groupId", groupId);
        startActivity(intent);
    }


    public void setGroupSearchFoundLayout() {
        Cursor groupMembers = dbManager.open().fetchGroupMembers(groupId);

        if (groupMembers.getCount() > 0) {

            Cursor cursor1 = dbManager.open().fetchGroupMemberAvailability(groupId, user_id);

            if (cursor1.getCount() > 0) {
                userPresent = true;
                groupLinkJoinBtn.setText("Open group");
            } else {
                groupLinkJoinBtn.setText("Join group");
            }
        }

        groupTitle.setText(title);
        groupTotalCount.setText(String.valueOf(groupMembers.getCount()));
        groupLinkBox.setText(searchJoinLinkFieldValue);

        groupMemberCount = groupMembers.getCount();

    }

}