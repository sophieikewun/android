package com.example.databasemadeeasy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class MiddleWareSystem extends Activity {

    SharedPreferences pref;
    public static final String myPreference = "mypref";
    public static final String User_ID = "userId";
    public static final String User_Role = "roleKey";
    Context cxt;
    SharedPreferences.Editor editor;


    public MiddleWareSystem(Context context) {
        pref = context.getSharedPreferences(myPreference, Context.MODE_PRIVATE);
        cxt = context;
        editor = pref.edit();
    }

    public void getMiddleFunction() {
        if (pref.contains(User_ID) && pref.contains(User_Role)) {
//            Intent i = new Intent(cxt.getApplicationContext(), Base_page.class);
            Intent i = new Intent(cxt.getApplicationContext(), Main_login.class);
            startActivity(i);
        }
        else{
//            Intent intent = new Intent(cxt.getApplicationContext(), Main_login.class);
//            startActivity(intent);
        }
    }

    public void setMiddleFunction(int id, int role) {
        editor.putInt(User_ID, id);
        editor.putInt(User_Role, role);
        editor.commit();
    }

    public void resetMiddleFunction() {
        editor.clear();
        editor.commit();
    }
}
