package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Main_login extends AppCompatActivity {

    ImageView backBtn;
    Button signupBtn, loginBtn;
    EditText emailField, passwordField;
    TextView forgotPwdBtn, messageBox;
    DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);

        backBtn = findViewById(R.id.backBtn);
        signupBtn = findViewById(R.id.signInBtn);
        loginBtn = findViewById(R.id.verifyBtn);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        forgotPwdBtn = findViewById(R.id.forgotPwdBtn);
        messageBox = findViewById(R.id.messageBox);
        dbManager = new DBManager(getApplicationContext());

        emailField.setText("sampleuser@mail.com");
        passwordField.setText("samplee");


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Signup.class));
            }
        });

        forgotPwdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Password_reset.class));
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailValue = emailField.getText().toString();
                String passwordValue = passwordField.getText().toString();

                if(emailValue.isEmpty() || passwordValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    dbManager.open();
                    Cursor cursor = dbManager.fetchDataBySpecificColumn("user", emailValue, "email");

                    if (cursor.getCount() == 0) {
                        setMessageBox("Incorrect Details");
                    } else {
                        String dbEmail = "";
                        String dbPassword = "";
                        int userId = 0;
                        int userRole = 0;
                        String activated = "0";

                        while(cursor.moveToNext()) {
                            userId = Integer.parseInt(cursor.getString(0));
                            dbEmail = cursor.getString(2);
                            dbPassword = cursor.getString(3);
                            userRole = Integer.parseInt(cursor.getString(4));
                            activated = cursor.getString(5);
                        }

                        if(emailValue.equals(dbEmail) && passwordValue.equals(dbPassword) ) {
                            if(activated.equals("1")) {
                                MiddleWareSystem middleWareSystem = new MiddleWareSystem(getApplicationContext());
                                middleWareSystem.setMiddleFunction(userId, userRole);

                                startActivity(new Intent(getApplicationContext(), Base_page.class));
                                Toast.makeText(getApplicationContext(), "Logged in successfully ", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent i = new Intent(v.getContext(), Verify_email.class);
                                i.putExtra("email", emailValue);
                                i.putExtra("userId", userId);
                                startActivity(i);

                                Toast.makeText(getApplicationContext(), "Activate Account ", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            setMessageBox("Incorrect Details");
                        }
                    }
                }
            }
        });
    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }

}