package com.example.databasemadeeasy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class explore extends Fragment {
    Button searchBtn;
    TextView explore_user_name, exploreCourseSeeAll, exploreTopicSeeAll;
    SharedPreferences sharedPreferences;
    String user_id;

    DBManager dbManager;
    ArrayList<String> courseId, courseName, excerpt, lastModified, category;

    RecyclerView courseExploreRecycler;
    AdapterCourseMain adapterCourseMain;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_explore, container, false);

        searchBtn = view.findViewById(R.id.editTextTextPersonName8);
        explore_user_name = view.findViewById(R.id.explore_user_name);
        courseExploreRecycler = view.findViewById(R.id.courseExploreRecycler);
        exploreCourseSeeAll = view.findViewById(R.id.exploreCourseSeeAll);
        exploreTopicSeeAll = view.findViewById(R.id.exploreTopicSeeAll);

        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        excerpt = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();

        sharedPreferences = getContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));
        dbManager = new DBManager(getContext());
        adapterCourseMain = new AdapterCourseMain(view.getContext(), courseId, courseName, excerpt, lastModified, category);

        setUsername();
        setPopularItems();

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(), Search_page.class));
            }
        });

        explore_user_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               switchPage(Profile.class);
            }
        });

        exploreCourseSeeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               switchPage(Courses.class);
            }
        });

        exploreTopicSeeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               switchPage(Courses.class);
            }
        });

        return view;
    }

    void switchPage(Class className) {
        FragmentManager fm = getParentFragmentManager();

        fm.beginTransaction()
                .replace(R.id.fragmentContainerView, className, null)
                .setReorderingAllowed(true)
                .addToBackStack("name")
                .commit();
    }

    void setPopularItems() {
        storeDataInArrays();

        GridLayoutManager layoutManager = new GridLayoutManager(getContext(),4);
        courseExploreRecycler.setAdapter(adapterCourseMain);
        courseExploreRecycler.setLayoutManager(layoutManager);
    }

    public void setUsername() {
        DBManager dbManager = new DBManager(getContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchDataById("user", user_id, "userId");

        if(cursor.getCount() == 0) {
            explore_user_name.setText("Null");
        } else {
            while(cursor.moveToNext()) {
                explore_user_name.setText(cursor.getString(1));
            }
        }
    }

    void storeDataInArrays() {
        DBManager dbManager = new DBManager(getContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchPopularCourse();

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                excerpt.add(cursor.getString(3));
                lastModified.add(cursor.getString(4));
                category.add(cursor.getString(5));
            }
        }
    }


}