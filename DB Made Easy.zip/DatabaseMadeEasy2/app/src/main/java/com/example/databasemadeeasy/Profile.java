package com.example.databasemadeeasy;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.paris.Paris;

import java.util.ArrayList;

public class Profile extends Fragment {
    Button personalBtn, secBtn, profilePasswordUpdateBtn;

    EditText profileFullNameInput, profileEmailAddressInput, profilePhoneInput, profileOldPasswordInput, profileNewPasswordInput, profileConfirmNewPasswordInput;

    TextView profileCategory, profileCourseCount, profileGroupCount, profileUserName, profileErrorText;
    LinearLayout profleContentHolder, personalLayout, passwordLayout;
    FragmentManager fm;

    SharedPreferences sharedPreferences;
    String user_id;

    Cursor cursor, courseCursor, groupCursor;

    ArrayList<String> userDetail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        fm = getParentFragmentManager();
        personalBtn = view.findViewById(R.id.courseDetailShelfAddBtn);
        secBtn = view.findViewById(R.id.secBtn);
        profileCategory = view.findViewById(R.id.profileCategory);
        profileCourseCount = view.findViewById(R.id.profileCourseCount);
        profileGroupCount = view.findViewById(R.id.profileGroupCount);
        profileUserName = view.findViewById(R.id.profileUserName);
        profleContentHolder = view.findViewById(R.id.profleContentHolder);
        profileErrorText = view.findViewById(R.id.profileErrorText);
        profileFullNameInput = view.findViewById(R.id.profileFullNameInput);
        profileEmailAddressInput = view.findViewById(R.id.profileEmailAddressInput);
        profilePhoneInput = view.findViewById(R.id.profilePhoneInput);
        profileOldPasswordInput = view.findViewById(R.id.profileOldPasswordInput);
        profileNewPasswordInput = view.findViewById(R.id.profileNewPasswordInput);
        profileConfirmNewPasswordInput = view.findViewById(R.id.profileConfirmNewPasswordInput);
        personalLayout = view.findViewById(R.id.personalLayout);
        passwordLayout = view.findViewById(R.id.passwordLayout);
        profilePasswordUpdateBtn = view.findViewById(R.id.profilePasswordUpdateBtn);


        sharedPreferences = getContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));

        userDetail = new ArrayList<>();
        DBManager dbManager = new DBManager(getContext());
        dbManager.open();

        cursor = dbManager.fetchDataById("user", user_id, "userId");
        courseCursor = dbManager.fetchDataById("shelf", user_id, "userId");
        groupCursor = dbManager.fetchDataById("groupmembers", user_id, "userId");

        populateArray();
        setProfileDetail();
        setProfilePersonalInfo();


        personalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Paris.style(personalBtn).apply(R.style.profileActiveSwitcher);
                Paris.style(secBtn).apply(R.style.profileInactiveSwitcher);

                setProfilePersonalInfo();
            }
        });

        secBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Paris.style(secBtn).apply(R.style.profileActiveSwitcher);
                Paris.style(personalBtn).apply(R.style.profileInactiveSwitcher);

                personalLayout.setVisibility(View.GONE);
                passwordLayout.setVisibility(View.VISIBLE);
            }
        });

        profilePasswordUpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String oldPass = profileOldPasswordInput.getText().toString();
                String newPass = profileNewPasswordInput.getText().toString();
                String confirmPass = profileConfirmNewPasswordInput.getText().toString();

                if(oldPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
                    Toast.makeText(getContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    if (newPass.equals(confirmPass)) {
                        if (oldPass.equals(userDetail.get(3))) {
                            dbManager.updateUserPassword(user_id, newPass);
                            resetPasswordInput();
                            getActivity().recreate();
                        } else {
                            Toast.makeText(getContext(), "Invalid password", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(), "New password and confirm does not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Inflate the layout for this fragment
        return view;
    }



    public void populateArray() {
        if (cursor.getCount() == 0) {
        } else {
            while (cursor.moveToNext()) {
                userDetail.add(cursor.getString(0));
                userDetail.add(cursor.getString(1));
                userDetail.add(cursor.getString(2));
                userDetail.add(cursor.getString(3));
                userDetail.add(cursor.getString(4));
            }
        }
    }

    public void setProfileDetail() {
        if (userDetail.size() == 0) {
            profileErrorText.setVisibility(View.VISIBLE);
            profleContentHolder.setVisibility(View.GONE);

        } else {
            profileErrorText.setVisibility(View.GONE);
            profleContentHolder.setVisibility(View.VISIBLE);

            profileCategory.setText("0");
            profileGroupCount.setText(String.valueOf(groupCursor.getCount()));
            profileCourseCount.setText(String.valueOf(courseCursor.getCount()));
            profileUserName.setText(userDetail.get(1));
        }
    }

    void setProfilePersonalInfo() {
        passwordLayout.setVisibility(View.GONE);
        personalLayout.setVisibility(View.VISIBLE);

        profileFullNameInput.setText(userDetail.get(1));
        profileEmailAddressInput.setText(userDetail.get(2));
        resetPasswordInput();
    }

    void resetPasswordInput() {
        profileOldPasswordInput.setText("");
        profileNewPasswordInput.setText("");
        profileConfirmNewPasswordInput.setText("");
    }



}