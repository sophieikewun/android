package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.paris.Paris;

import java.util.ArrayList;

public class myshelf extends AppCompatActivity {

    DBManager dbManager;
    ArrayList<String> courseId, courseName, lastModified, category;

    RecyclerView courseShelfProgRecycler;
    AdapterShelf adapterShelf;
    TextView emptyTextview;
    EditText searchShelfBox;
    LinearLayout btnChangerLayout;

    ImageView shelfBackBtn, menuBtn;
    Button onGoingBtn, completedBtn;

    SharedPreferences sharedPreferences;
    String user_id;
    String activeGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myshelf);

        shelfBackBtn = findViewById(R.id.shelfBackBtn);
        onGoingBtn = findViewById(R.id.onGoingBtn);
        completedBtn = findViewById(R.id.completedBtn);
        emptyTextview = findViewById(R.id.emptyTextview);
        menuBtn = findViewById(R.id.menuBtn);
        searchShelfBox = findViewById(R.id.editTextTextPersonName8);
        courseShelfProgRecycler = findViewById(R.id.courseShelfProgRecycler);
        btnChangerLayout = findViewById(R.id.btnChangerLayout);


        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();

        dbManager = new DBManager(getApplicationContext());

        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));

        storeDataInArrays("0");
        activeGroup = "0";
        emptyTextview.setVisibility(View.VISIBLE);
        contentContainer ();


        searchShelfBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int length = searchShelfBox.length();
                if (length < 1) {
                    btnChangerLayout.setVisibility(View.VISIBLE);

                    storeDataInArrays(activeGroup);
                    emptyTextview.setVisibility(View.VISIBLE);
                    contentContainer ();

                } else {
                    String searchValue = searchShelfBox.getText().toString();

                    btnChangerLayout.setVisibility(View.GONE);

                    storeSearchDataInArrays(user_id, searchValue);
                    emptyTextview.setVisibility(View.VISIBLE);
                    contentContainer ();
                }
            }
        });

        shelfBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Menu.class));
            }
        });

        onGoingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                        cc();
                Paris.style(onGoingBtn).apply(R.style.shelfActive);
                Paris.style(completedBtn).apply(R.style.shelfInactive);

                btnRunner("0");
                activeGroup = "0";

            }
        });

        completedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Paris.style(completedBtn).apply(R.style.shelfActive);
                Paris.style(onGoingBtn).apply(R.style.shelfInactive);

                btnRunner("1");
                activeGroup = "1";
            }
        });
    }

    public void contentContainer () {
        if(courseId.size() > 0) {
            displayResult();
        }
        else {
            courseShelfProgRecycler.setVisibility(View.GONE);
            emptyTextview.setVisibility(View.VISIBLE);
        }
    }

    public void btnRunner(String shelfType) {
        storeDataInArrays(shelfType);
        contentContainer ();
    }

    public void displayResult() {
        emptyTextview.setVisibility(View.GONE);
        courseShelfProgRecycler.setVisibility(View.VISIBLE);

        adapterShelf = new AdapterShelf(getApplicationContext(), courseId, courseName, lastModified, category);
        GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),1);

        courseShelfProgRecycler.setAdapter(adapterShelf);
        courseShelfProgRecycler.setLayoutManager(layoutManager);
    }

    public void storeSearchDataInArrays(String userId, String searchValue) {
        dbManager.open();

        courseId.clear();
        courseName.clear();
        lastModified.clear();
        category.clear();

        Cursor cursor = dbManager.searchForShelfCourse(userId, searchValue);

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                lastModified.add(cursor.getString(2));
                category.add(cursor.getString(3));
            }
        }
    }

    public void storeDataInArrays(String shelfType) {
        dbManager.open();

        courseId.clear();
        courseName.clear();
        lastModified.clear();
        category.clear();

        Cursor cursor = dbManager.fetchShelfData(shelfType, user_id);

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                lastModified.add(cursor.getString(2));
                category.add(cursor.getString(3));
            }
        }
    }




}