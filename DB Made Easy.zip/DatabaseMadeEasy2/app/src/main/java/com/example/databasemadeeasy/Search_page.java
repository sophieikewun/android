package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Search_page extends AppCompatActivity {
    ImageView searchBackBtn, searchCourseBtn;
    TextView textView66, textView67, textView68, textView69, emptyLabel;
    EditText searchField;
    LinearLayout baseContainer;
    NestedScrollView searchScrollContainer;

    DBManager dbManager;
    ArrayList<String> courseId, courseName, excerpt, lastModified, category;

    RecyclerView searchRecyclerView;
    AdapterCourseMain adapterCourseMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);

        searchBackBtn = findViewById(R.id.searchBackBtn);
        textView66 = findViewById(R.id.textView66);
        textView67 = findViewById(R.id.textView67);
        textView68 = findViewById(R.id.textView68);
        textView69 = findViewById(R.id.textView69);
        searchField = findViewById(R.id.editTextTextPersonName8);
        searchRecyclerView = findViewById(R.id.searchRecyclerView);
        baseContainer = findViewById(R.id.baseContainer);
        emptyLabel = findViewById(R.id.textView35);
        searchScrollContainer = findViewById(R.id.searchScrollContainer);


        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        excerpt = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();
        dbManager = new DBManager(getApplicationContext());

        baseContainer.setVisibility(View.VISIBLE);
        emptyLabel.setVisibility(View.GONE);
        searchScrollContainer.setVisibility(View.GONE);

        searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int length = searchField.length();
                if (length < 1) {
                    baseContainer.setVisibility(View.VISIBLE);
                    emptyLabel.setVisibility(View.GONE);
                    searchScrollContainer.setVisibility(View.GONE);
                } else {
                    String searchFieldValue = searchField.getText().toString();
                    storeDataInArrays(searchFieldValue);
                    baseContainer.setVisibility(View.GONE);

                    if (courseId.size() < 1) {
                        emptyLabel.setVisibility(View.VISIBLE);
                        searchScrollContainer.setVisibility(View.GONE);
                    } else {
                        emptyLabel.setVisibility(View.GONE);
                        searchScrollContainer.setVisibility(View.VISIBLE);

                        adapterCourseMain = new AdapterCourseMain(getApplicationContext(), courseId, courseName, excerpt, lastModified, category);

                        GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 2);

                        searchRecyclerView.setAdapter(adapterCourseMain);
                        searchRecyclerView.setLayoutManager(layoutManager);

                    }
                }
            }
        });


        searchBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        textView66.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(1);
            }
        });
        textView67.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(2);
            }
        });
        textView68.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(3);
            }
        });
        textView69.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(4);
            }
        });
    }

    void openPage(int categoryId) {
        Intent intent = new Intent(getApplicationContext(), CourseCategoryMain.class);
        intent.putExtra("categoryId", categoryId);
        startActivity(intent);
    }

    void storeDataInArrays(String searchValue) {
        dbManager.open();

        Cursor cursor = dbManager.searchForCourse(searchValue);

        courseId.clear();
        courseName.clear();
        excerpt.clear();
        lastModified.clear();
        category.clear();

        if (cursor.getCount() == 0) {
            System.out.println("Empty");
        } else {
            while (cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                excerpt.add(cursor.getString(3));
                lastModified.add(cursor.getString(4));
                category.add(cursor.getString(5));
            }
        }
    }
}