package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class GroupMainPage extends AppCompatActivity {

    String groupId;
    TextView title, description, link;
    ImageView backBtn, copyToClipboard;
    ArrayList<String> userFullNames;
    RecyclerView courseCategoryMainRecycler11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_main_page);

        title = findViewById(R.id.textView16);
        description = findViewById(R.id.textView19);
        link = findViewById(R.id.textView20);
        backBtn = findViewById(R.id.imageView8);
        copyToClipboard = findViewById(R.id.copyToClipboard);

        courseCategoryMainRecycler11 = findViewById(R.id.courseCategoryMainRecycler11);

        userFullNames = new ArrayList<>();


        Bundle bundle = getIntent().getExtras();
        groupId = bundle.getString("groupId");


        DBManager dbManager = new DBManager(getApplicationContext());
        Cursor cursor = dbManager.open().fetchDataById("groups", groupId, "groupId");

        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                title.setText(cursor.getString(1));
                description.setText(cursor.getString(2));
                link.setText(cursor.getString(3));
            }
        }

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        copyToClipboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipMan = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("link", link.getText());
                clipMan.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(), "Text copied successfully", Toast.LENGTH_SHORT).show();
            }
        });


        Cursor groupMembers = dbManager.open().fetchGroupMembers(groupId);
        if (groupMembers.getCount() > 0) {
            while (groupMembers.moveToNext()) {
                userFullNames.add(groupMembers.getString(0));
            }

            AdapterGroupMember adapterGroupMember = new AdapterGroupMember(getApplicationContext(), userFullNames);
            GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 1);


            courseCategoryMainRecycler11.setAdapter(adapterGroupMember);
            courseCategoryMainRecycler11.setLayoutManager(layoutManager);
        }

    }
}




