package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.UUID;

public class create_group extends AppCompatActivity {

    EditText createGroupTitle, createGroupDescription;
    ImageView createGroupBtn, backBtn;


    SharedPreferences sharedPreferences;
    String user_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);


        backBtn = findViewById(R.id.backBtn);
        createGroupBtn = findViewById(R.id.createGroupBtn);
        createGroupTitle = findViewById(R.id.createGroupTitle);
        createGroupDescription = findViewById(R.id.createGroupDescription);


        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", getApplicationContext().MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));


        createGroupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBManager dbManager = new DBManager(getApplicationContext());
                String titleValue = createGroupTitle.getText().toString();
                String descriptionValue = createGroupDescription.getText().toString();



                if(titleValue.isEmpty() || descriptionValue.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    String link = UUID.randomUUID().toString().replace("-", "");
                    String link1 = UUID.randomUUID().toString().replace("-", "");

                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(link);
                    stringBuilder.append(link1);

                    int groupId = (int) dbManager.open().insertGroup(titleValue, descriptionValue, stringBuilder.toString());

                    dbManager.open().insertGroupMember(user_id, String.valueOf(groupId));

                    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    dbManager.open().insertNotification(Integer.parseInt(user_id), new NotificationMessage().createGroupMessage(titleValue), sdf3.format(new Timestamp(System.currentTimeMillis())), "New group created");


                    Intent intent = new Intent(getApplicationContext(), GroupMainPage.class);
                    intent.putExtra("groupId", String.valueOf(groupId));
                    startActivity(intent);
                }
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}