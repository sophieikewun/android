package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class NotificationDetails extends AppCompatActivity {
    TextView notificationTitle, notificationMessage, notificationTImestamp;
    ImageView notifyBackBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_details);

        notificationTitle = findViewById(R.id.notificationTitle);
        notificationMessage = findViewById(R.id.notificationMessage);
        notifyBackBtn = findViewById(R.id.notifyBackBtn);
        notificationTImestamp = findViewById(R.id.notificationTImestamp);

        Bundle bundle = getIntent().getExtras();

        notificationTitle.setText(bundle.getString("notificationTitle"));
        notificationMessage.setText(bundle.getString("notificationMessage"));
        notificationTImestamp.setText(bundle.getString("notificationTimestamp"));


        notifyBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}