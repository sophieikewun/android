package com.example.databasemadeeasy;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(@Nullable Context context) {
        super(context, "Database made easy", null, 1);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String user = "CREATE TABLE user (userId integer primary key autoincrement, fullname text not null, email text not null unique, password text not null, role integer not null default 0, activated integer not null default 0);";

        String otp = "CREATE TABLE otp (otpId integer primary key autoincrement, otp_code integer not null, userId integer not null, timeToExpire text not null, constraint fk_otp_userid foreign key(userId) references user(userId));";

        String category = "CREATE TABLE category (categoryId integer primary key autoincrement, categoryName text not null);";

        String course = "CREATE TABLE course (courseId integer primary key autoincrement, courseName text not null, description text not null, excerpt text not null, lastModified text not null, categoryId integer not null, constraint fk_course_categoryid foreign key(categoryId) references category(categoryId) );";

        String score = "CREATE TABLE score (scoreId integer primary key autoincrement, userId integer not null, courseId integer not null, score integer not null, constraint fk_score_userid foreign key(userId) references user(userId), constraint fk_score_courseid foreign key(courseId) references course(courseId));";

        String shelf = "CREATE TABLE shelf(shelfId integer primary key autoincrement, userId integer not null, courseId integer not null, completed integer not null default 0, constraint fk_shelf_userid foreign key(userId) references user(userId), constraint fk_shelf_courseid foreign key(courseId) references course(courseId));";

        String notification = "CREATE TABLE notification(notificationId integer primary key autoincrement, userId integer not null, message text not null, timestamp text not null, title text not null, constraint fk_notification_userid foreign key(userId) references user(userId));";

        String groups = "CREATE TABLE groups(groupId integer primary key autoincrement, title text not null, description text not null, link text not null);";

        String groupMember = "CREATE TABLE groupmembers(rowId integer primary key autoincrement, userId integer not null, groupsId integer not null, constraint fk_group_member_userid foreign key(userId) references user(userId), constraint fk_group_member_groupsid foreign key(groupsId) references groups(groupId) );";

        String questionsTable = "CREATE TABLE questionstable(questionsTableId integer primary key autoincrement, question text not null, option1 text not null, option2 text not null, option3 text not null, answerNr text not null, categoryId text not null,  constraint fk_course_categoryid foreign key(categoryId) references category(categoryId)  );";

        String testScore = "CREATE TABLE testScore(testScoreId integer primary key autoincrement, userId integer not null, questionId integer not null, constraint fk_test_score_userId foreign key(userId) references user(userId), constraint fk_test_score_questionId foreign key(questionId) references questionstable(queestionsTableId))";

        db.execSQL(user);
        db.execSQL(otp);
        db.execSQL(category);
        db.execSQL(course);
        db.execSQL(score);
        db.execSQL(shelf);
        db.execSQL(notification);
        db.execSQL(groups);
        db.execSQL(groupMember);
        db.execSQL(questionsTable);
        db.execSQL(testScore);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS otp");
        db.execSQL("DROP TABLE IF EXISTS course");
        db.execSQL("DROP TABLE IF EXISTS score");
        db.execSQL("DROP TABLE IF EXISTS shelf");
        db.execSQL("DROP TABLE IF EXISTS notification");
        db.execSQL("DROP TABLE IF EXISTS questionsTable");
        db.execSQL("DROP TABLE IF EXISTS testScore");

        onCreate(db);
    }



}
