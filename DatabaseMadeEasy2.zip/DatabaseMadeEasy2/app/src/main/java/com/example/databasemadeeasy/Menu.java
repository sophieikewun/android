package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Menu extends AppCompatActivity {
    ImageView closeNav;
    TextView shelfNav, categoriesNav, groupsNav, assessmentNav, certificationNav, homeNav, logoutNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        closeNav = findViewById(R.id.closeNav);

        homeNav = findViewById(R.id.homeNav);
        shelfNav = findViewById(R.id.shelfNav);
        categoriesNav = findViewById(R.id.categoriesNav);
        groupsNav = findViewById(R.id.groupsNav);
        assessmentNav = findViewById(R.id.assessmentNav);
        certificationNav = findViewById(R.id.certificationNav);
        logoutNav = findViewById(R.id.logoutNav);

        closeNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        homeNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Base_page.class));
            }
        });
        shelfNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), myshelf.class));
            }
        });
        categoriesNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Base_page.class);
                i.putExtra("pageValue", "CourseCategories");
                startActivity(i);
            }
        });
        groupsNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), group.class));
            }
        });
        assessmentNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), AssessmentPath.class));
            }
        });
        certificationNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Base_page.class);
                i.putExtra("pageValue", "Certification");
                startActivity(i);
            }
        });
        logoutNav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MiddleWareSystem wareSystem = new MiddleWareSystem(getApplicationContext());
                wareSystem.resetMiddleFunction();

                Intent i = new Intent(getApplicationContext(), Main_login.class);
                startActivity(i);
                Toast.makeText(getApplicationContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();
            }
        });


    }
}