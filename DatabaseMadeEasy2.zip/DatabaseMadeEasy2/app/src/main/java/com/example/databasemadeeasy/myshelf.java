package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.paris.Paris;

import java.util.ArrayList;

public class myshelf extends AppCompatActivity {

    DBManager dbManager;
    ArrayList<String> courseId, courseName, lastModified, category;

    RecyclerView courseShelfProgRecycler;
    AdapterShelf adapterShelf;
    TextView emptyTextview;

    ImageView shelfBackBtn, menuBtn;
    Button onGoingBtn, completedBtn;

    SharedPreferences sharedPreferences;
    String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myshelf);

        shelfBackBtn = findViewById(R.id.shelfBackBtn);
        onGoingBtn = findViewById(R.id.onGoingBtn);
        completedBtn = findViewById(R.id.completedBtn);
        emptyTextview = findViewById(R.id.emptyTextview);
        menuBtn = findViewById(R.id.menuBtn);


        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();
        courseShelfProgRecycler = findViewById(R.id.courseShelfProgRecycler);

        dbManager = new DBManager(getApplicationContext());

        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));

        storeDataInArrays("0");
        emptyTextview.setVisibility(View.VISIBLE);
        contentContainer ();


        shelfBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Menu.class));
            }
        });

        onGoingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                        cc();
                Paris.style(onGoingBtn).apply(R.style.shelfActive);
                Paris.style(completedBtn).apply(R.style.shelfInactive);

                btnRunner("0");
            }
        });

        completedBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Paris.style(completedBtn).apply(R.style.shelfActive);
                Paris.style(onGoingBtn).apply(R.style.shelfInactive);

                btnRunner("1");
            }
        });
    }

    public void contentContainer () {
        if(courseId.size() > 0) {
            displayResult();
        }
        else {
            courseShelfProgRecycler.setVisibility(View.GONE);
            emptyTextview.setVisibility(View.VISIBLE);
        }
    }

    public void btnRunner(String shelfType) {
        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();
        storeDataInArrays(shelfType);
        contentContainer ();
    }

    public void displayResult() {
        emptyTextview.setVisibility(View.GONE);
        courseShelfProgRecycler.setVisibility(View.VISIBLE);

        adapterShelf = new AdapterShelf(getApplicationContext(), courseId, courseName, lastModified, category);
        GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),1);

        courseShelfProgRecycler.setAdapter(adapterShelf);
        courseShelfProgRecycler.setLayoutManager(layoutManager);
    }

    public void storeDataInArrays(String shelfType) {
        dbManager.open();

        Cursor cursor = dbManager.fetchShelfData(shelfType, user_id);

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                lastModified.add(cursor.getString(2));
                category.add(cursor.getString(3));
            }
        }
    }




}