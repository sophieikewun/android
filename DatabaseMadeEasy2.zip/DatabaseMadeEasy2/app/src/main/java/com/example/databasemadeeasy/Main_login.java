package com.example.databasemadeeasy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Main_login extends AppCompatActivity {

    ImageView backBtn;
    Button signupBtn, loginBtn;
    EditText emailField, passwordField;
    TextView forgotPwdBtn, messageBox;
    DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);

//        cc();

        backBtn = findViewById(R.id.backBtn);
        signupBtn = findViewById(R.id.signInBtn);
        loginBtn = findViewById(R.id.verifyBtn);
        emailField = findViewById(R.id.emailField);
        passwordField = findViewById(R.id.passwordField);
        forgotPwdBtn = findViewById(R.id.forgotPwdBtn);
        messageBox = findViewById(R.id.messageBox);
        dbManager = new DBManager(getApplicationContext());


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Signup.class));
            }
        });

        forgotPwdBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Password_reset.class));
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailValue = emailField.getText().toString();
                String passwordValue = passwordField.getText().toString();

                if(emailValue.isEmpty() || passwordValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    dbManager.open();
                    Cursor cursor = dbManager.fetchDataBySpecificColumn("user", emailValue, "email");

                    if (cursor.getCount() == 0) {
                        setMessageBox("Incorrect Details");
                    } else {
                        String dbEmail = "";
                        String dbPassword = "";
                        int userId = 0;
                        int userRole = 0;
                        String activated = "0";

                        while(cursor.moveToNext()) {
                            userId = Integer.parseInt(cursor.getString(0));
                            dbEmail = cursor.getString(2);
                            dbPassword = cursor.getString(3);
                            userRole = Integer.parseInt(cursor.getString(4));
                            activated = cursor.getString(5);
                        }

                        if(emailValue.equals(dbEmail) && passwordValue.equals(dbPassword) ) {
                            if(activated.equals("1")) {
                                MiddleWareSystem middleWareSystem = new MiddleWareSystem(getApplicationContext());
                                middleWareSystem.setMiddleFunction(userId, userRole);

                                startActivity(new Intent(getApplicationContext(), Base_page.class));
                                Toast.makeText(getApplicationContext(), "Logged in successfully ", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent i = new Intent(v.getContext(), Verify_email.class);
                                i.putExtra("email", emailValue);
                                i.putExtra("userId", userId);
                                startActivity(i);

                                Toast.makeText(getApplicationContext(), "Activate Account ", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            setMessageBox("Incorrect Details");
                        }
                    }
                }
            }
        });
    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }


    public void cc() {
        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        dbManager.insertUser("Sample user", "sampleuser@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Sophia Ikewun", "sophiaikewun@mail.com", "samplee", 0, 1);
        dbManager.insertUser("Ikewun Zoe", "ikewunzoe@mail.com", "samplee", 0, 1);

        dbManager.insertCategory("Beginner");
        dbManager.insertCategory("Intermediate");
        dbManager.insertCategory("Advanced");
        dbManager.insertCategory("Expert");

        dbManager.insertCourse("Database for dummy", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 1);

        dbManager.insertCourse("Fundamentals of database", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 1);

        dbManager.insertCourse("Advances in database operations", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 1);

        dbManager.insertCourse("College Database", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 2);

        dbManager.insertCourse("Variables Data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 3);

        dbManager.insertCourse("Machine learning data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 4);

        dbManager.insertCourse("Sample Data", "Nam in nibh venenatis, aliquam sapien at, auctor ipsum. Maecenas semper nisi vel elit congue, suscipit ornare magna semper. Phasellus a venenatis enim. Maecenas consequat sem ut lectus facilisis, ut posuere diam bibendum. Curabitur urna purus, dignissim quis pharetra ac, molestie eu eros. Nulla fringilla nulla id massa sagittis, quis consectetur enim efficitur. Curabitur quis feugiat nisl, id posuere massa. Morbi ornare gravida ante, eget dapibus urna. Nullam lobortis dapibus risus ac rutrum. Aliquam aliquet ex vel posuere volutpat. Donec tristique elit nec velit rutrum, a suscipit massa auctor. Nunc nec urna arcu. Nam ac hendrerit nulla, at egestas nulla.\n" +
                "\n" +
                "Nullam erat enim, lobortis et libero a, condimentum vulputate magna. Maecenas facilisis mi in augue suscipit, id commodo enim fringilla. Aliquam facilisis scelerisque nibh, ac cursus sapien laoreet ut. Vestibulum tempor felis mi, eget malesuada sem eleifend et. Phasellus dictum nisl libero, ac porttitor turpis porta quis. In ultrices porta mollis. Vivamus porttitor risus velit, a tempus tellus pharetra a. Donec orci dolor, fermentum et cursus vel, rutrum consequat metus. Nulla vitae gravida est, ut sagittis ex. Morbi sodales porttitor consequat. Pellentesque vehicula tincidunt turpis non tristique. Morbi at euismod enim. Phasellus nibh dolor, tempor at eros sit amet, varius congue ligula. Vestibulum quis aliquam nunc. Nulla nec varius massa. In hac habitasse platea dictumst.\n" +
                "\n" +
                "Nullam euismod in arcu ac tristique. Sed efficitur massa et pulvinar aliquet. Sed quis mattis felis, nec aliquet lectus. Quisque elit ex, ornare at pulvinar eu, dapibus quis massa. Nulla cursus metus quam. Duis dapibus cursus libero convallis sagittis. Pellentesque in imperdiet felis, dapibus venenatis metus. Nulla ut nibh a ante bibendum tincidunt a quis est. Suspendisse mollis sapien non orci sodales consectetur. Vivamus quis sodales odio. Phasellus ac fringilla nulla. Morbi dapibus eu erat sit amet feugiat.", "This is just  a sample", sdf3.format(new Timestamp(System.currentTimeMillis())), 3);




        dbManager.insertNotification(1, "sample message subcription", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample1");
        dbManager.insertNotification(1, "Subscription User major", sdf3.format(new Timestamp(System.currentTimeMillis())), "sample2");
        dbManager.insertNotification(1, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
        dbManager.insertNotification(2, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
        dbManager.insertNotification(3, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");

        dbManager.insertShelf(1, 1, 0);
        dbManager.insertShelf(1, 2, 0);
        dbManager.insertShelf(1, 3, 0);
        dbManager.insertShelf(1, 4, 1);
        dbManager.insertShelf(1, 5, 0);
        dbManager.insertShelf(1, 6, 1);
        dbManager.insertShelf(2, 3, 0);
        dbManager.insertShelf(3, 5, 0);

        dbManager.insertScore(3, 6, 60);

//        dbManager.insertOtp(2, 40000);
    }
}