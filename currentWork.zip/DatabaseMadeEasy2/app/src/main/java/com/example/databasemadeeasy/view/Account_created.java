package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Toast;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.controller.MiddleWareSystem;
import com.example.databasemadeeasy.R;

public class Account_created extends AppCompatActivity {
    int role = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_created);


        Bundle bundle = getIntent().getExtras();
        int userId = bundle.getInt("userId");
        DBManager dbManager = new DBManager(getApplicationContext());

        Cursor cursor = dbManager.open().fetchDataById("user", String.valueOf(userId), "userId");

        if (cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                role = Integer.parseInt(cursor.getString(4));
            }

            MiddleWareSystem middleWareSystem = new MiddleWareSystem(getApplicationContext());
            middleWareSystem.setMiddleFunction(Integer.parseInt(String.valueOf(userId)), role);

            new CountDownTimer(1000, 100) {
                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    startActivity(new Intent(getApplicationContext(), BasePage.class));
                    Toast.makeText(getApplicationContext(), "Logged in successfully ", Toast.LENGTH_SHORT).show();
                }
            }.start();
        }

        else {
            System.out.println(cursor.getCount());
            System.out.println("error");
        }
    }
}