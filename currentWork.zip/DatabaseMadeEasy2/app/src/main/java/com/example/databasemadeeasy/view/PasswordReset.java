package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.databasemadeeasy.R;

public class PasswordReset extends AppCompatActivity {

    ImageView backBtn;
    Button resetSendBtn;
    EditText resetEmailField;
    TextView messageBoxReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        backBtn = findViewById(R.id.backBtn);
        resetSendBtn = findViewById(R.id.verifyBtn);
        resetEmailField = findViewById(R.id.resetEmailField);
        messageBoxReset = findViewById(R.id.messageBoxReset);


        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        resetSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resetValue = resetEmailField.getText().toString();

                if(resetValue.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    resetEmailField.setText("");
                    startActivity(new Intent(getApplicationContext(), ResetSuccessful.class));
                }
            }
        });
    }


    public void setMessageBox(String message) {
        messageBoxReset.setText(message);
        messageBoxReset.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBoxReset.setVisibility(View.GONE);
            }
        }.start();
    }
}