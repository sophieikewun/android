package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.model.NotificationMessage;
import com.example.databasemadeeasy.R;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Course_details extends AppCompatActivity {

    ImageView backCourseDetailBtn, courseDetailShelfBtn;
    TextView courseDetailExcerpt, courseDetailTitle, courseDetailDate, courseDetailStudent, courseCategoryBtn;
    Button courseDetailShelfAddBtn;

    SharedPreferences sharedPreferences;
    String user_id;
    String course_id;
    boolean added = false;
    DBManager dbManager;

    LinearLayout courseDetailGroupOverlay;
    Button groupOverlayJoin, groupOverlayCreate, courseAddToGroupBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        backCourseDetailBtn = findViewById(R.id.backCourseDetailBtn);
        courseDetailShelfBtn = findViewById(R.id.courseDetailShelfBtn);
        courseDetailExcerpt = findViewById(R.id.courseDetailExcerpt);
        courseDetailTitle = findViewById(R.id.courseDetailTitle);
        courseDetailDate = findViewById(R.id.courseDetailDate);
        courseDetailStudent = findViewById(R.id.courseDetailStudent);
        courseDetailShelfAddBtn = findViewById(R.id.courseDetailShelfAddBtn);
        courseCategoryBtn = findViewById(R.id.courseCategoryBtn);

        courseDetailGroupOverlay = findViewById(R.id.courseDetailGroupOverlay);
        groupOverlayJoin = findViewById(R.id.groupOverlayJoin);
        groupOverlayCreate = findViewById(R.id.groupOverlayCreate);
        courseAddToGroupBtn = findViewById(R.id.courseAddToGroupBtn);

        courseAddToGroupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                courseDetailGroupOverlay.setVisibility(View.VISIBLE);
            }
        });

        courseDetailGroupOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getTag().equals("mainLayout")) {
                    v.setVisibility(View.INVISIBLE);
                }
            }
        });

        groupOverlayJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), OpenGroup.class));
            }
        });

        groupOverlayCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), CreateGroup.class));
            }
        });



        Bundle bundle = getIntent().getExtras();
        courseDetailExcerpt.setText(bundle.getString("courseExcerpt"));
        courseDetailTitle.setText(bundle.getString("courseName"));
        courseDetailDate.setText(bundle.getString("courseLastModified").split(" ")[0]);
        course_id = bundle.getString("courseId");

        courseCategoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CourseCategoryMain.class);
                intent.putExtra("categoryId", Integer.parseInt(bundle.getString("courseCategory")));
                startActivity(intent);
            }
        });

        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));

        dbManager = new DBManager(getApplicationContext());
        dbManager.open();
        Cursor cursor = dbManager.fetchCourseStudentDetail(Integer.parseInt(bundle.getString("courseId")));

        studentCount(cursor);
        pageBtnHandler();


        backCourseDetailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        courseDetailShelfBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MyShelf.class));
            }
        });

        courseDetailShelfAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (added) {
                    Intent intent = new Intent(getApplicationContext(), Course_content.class);
                    intent.putExtra("courseId", course_id);
                    startActivity(intent);
                } else {
                    dbManager.insertShelf(Integer.parseInt(user_id) ,Integer.parseInt(course_id) , 0);
                    added = true;

                    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    dbManager.open().insertNotification(Integer.parseInt(user_id), new NotificationMessage().courseMessage(bundle.getString("courseName")), sdf3.format(new Timestamp(System.currentTimeMillis())), "New course enrolled");


                    Cursor cursor = dbManager.fetchCourseStudentDetail(Integer.parseInt(bundle.getString("courseId")));

                    studentCount(cursor);
                    pageBtnHandler();
                }
            }
        });
    }

    public void pageBtnHandler() {
        Cursor cursor = dbManager.fetchCourseStudentEnrolled(user_id, course_id);

        if(cursor.getCount() == 0) {
            added = false;
            courseDetailShelfAddBtn.setText("Add to shelf");
        } else {
            added = true;
            courseDetailShelfAddBtn.setText("Go to course");
        }
    }

    public void studentCount(Cursor cursor) {
        if(cursor.getCount() == 0) {
            courseDetailStudent.setText(0);
        }
        else {
            while(cursor.moveToNext()) {
                courseDetailStudent.setText(cursor.getString(0));
            }
        }
    }

}