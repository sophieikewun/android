package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;
import com.example.databasemadeeasy.adapter.AdapterCourseMain;

import java.util.ArrayList;

public class CourseCategoryMain extends AppCompatActivity {

    DBManager dbManager;
    ArrayList<String> courseId, courseName, excerpt, lastModified, category;

    RecyclerView courseMainRecycler;
    AdapterCourseMain adapterCourseMain;

    TextView titleCourseCategory;
    ImageView shelfBackBtn, menuBtn;
    int categoryId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_category_main);

        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        excerpt = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();

        courseMainRecycler = findViewById(R.id.courseCategoryMainRecycler);
        titleCourseCategory = findViewById(R.id.titleCourseCategory);
        shelfBackBtn = findViewById(R.id.shelfBackBtn);
        menuBtn = findViewById(R.id.menuBtn);
        dbManager = new DBManager(getApplicationContext());

        Bundle bundle = getIntent().getExtras();
        categoryId = bundle.getInt("categoryId");


        setPageTitle();
        storeDataInArrays();


        shelfBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        menuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Menu.class));
            }
        });

        adapterCourseMain = new AdapterCourseMain(getApplicationContext(), courseId, courseName, excerpt, lastModified, category);
        GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
        courseMainRecycler.setAdapter(adapterCourseMain);
        courseMainRecycler.setLayoutManager(layoutManager);
    }


    void storeDataInArrays() {
        dbManager.open();

        Cursor cursor = dbManager.fetchDataById("course", String.valueOf(categoryId), "categoryId");

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                excerpt.add(cursor.getString(3));
                lastModified.add(cursor.getString(4));
                category.add(cursor.getString(5));
            }
        }
    }

    void setPageTitle() {
        switch (categoryId){
            case 1:
                titleCourseCategory.setText("Beginner");
                break;
            case 2:
                titleCourseCategory.setText("Intermediate");
                break;
            case 3:
                titleCourseCategory.setText("Advanced");
                break;
            case 4:
                titleCourseCategory.setText("Expert");
                break;
        }
    }

}