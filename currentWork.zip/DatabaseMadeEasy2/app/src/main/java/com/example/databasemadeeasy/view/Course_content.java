package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;

public class Course_content extends AppCompatActivity {

    ImageView back_btn;
    TextView courseTitle, courseDescription;
    Button takeAssessmentBtn;

    DBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_content);

        back_btn = findViewById(R.id.back_btn);
        courseTitle = findViewById(R.id.courseTitle);
        courseDescription = findViewById(R.id.courseDescription);
        takeAssessmentBtn = findViewById(R.id.takeAssessmentBtn);

        dbManager = new DBManager(getApplicationContext());
        dbManager.open();

        Bundle bundle = getIntent().getExtras();
        Cursor cursor = dbManager.fetchDataById("course", bundle.getString("courseId"), "courseId");

        if(cursor.getCount() == 0) {
            onBackPressed();
            Toast.makeText(getApplicationContext(), "Ensure you select a course first", Toast.LENGTH_SHORT).show();
        }
        else {
            while(cursor.moveToNext()) {
                courseTitle.setText(cursor.getString(1));
                courseDescription.setText(cursor.getString(2));
            }
        }


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        takeAssessmentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseID = bundle.getString("courseId");
                Intent intent = new Intent(getApplicationContext(), AssessmentPath.class);
                intent.putExtra("courseID", courseID);
                startActivity(intent);
            }
        });

    }
}