package com.example.databasemadeeasy.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.databasemadeeasy.view.Course_details;
import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;

import java.util.ArrayList;

public class AdapterCourseMain extends RecyclerView.Adapter<AdapterCourseMain.MyViewHolder> {

    private Context context;
    private Activity activity;
    ArrayList<String> courseId, courseName, excerpt, lastModified, category;

    public AdapterCourseMain(Context context, ArrayList courseId, ArrayList courseName, ArrayList excerpt, ArrayList lastModified, ArrayList category){
//        this.activity = activity;
        this.context = context;
        this.courseId = courseId;
        this.courseName = courseName;
        this.excerpt = excerpt;
        this.lastModified = lastModified;
        this.category = category;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_course, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.courseMainTitle.setText(String.valueOf(courseName.get(position)));
        holder.courseMainExcerpt.setText(String.valueOf(excerpt.get(position)));
        Cursor cursor = new DBManager(context.getApplicationContext()).open().fetchDataById("category", String.valueOf(category.get(position)), "categoryId");
        if(cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                holder.courseMainCategory.setText(cursor.getString(1));
            }
        }
        //Recyclerview onClickListener
        holder.courseMainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Course_details.class);
                intent.putExtra("courseId", String.valueOf(courseId.get(position)));
                intent.putExtra("courseName", String.valueOf(courseName.get(position)));
                intent.putExtra("courseExcerpt", String.valueOf(excerpt.get(position)));
                intent.putExtra("courseLastModified", String.valueOf(lastModified.get(position)));
                intent.putExtra("courseCategory", String.valueOf(category.get(position)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return this.courseId.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView courseMainTitle, courseMainExcerpt, courseMainCategory;
        LinearLayout courseMainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            courseMainTitle = itemView.findViewById(R.id.courseMainTitle);
            courseMainExcerpt = itemView.findViewById(R.id.courseMainExcerpt);
            courseMainCategory = itemView.findViewById(R.id.courseMainCategory);
            courseMainLayout = itemView.findViewById(R.id.courseMainLayout);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
