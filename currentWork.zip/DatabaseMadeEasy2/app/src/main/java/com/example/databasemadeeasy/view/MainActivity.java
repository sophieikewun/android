package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.LinearLayout;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;

public class MainActivity extends AppCompatActivity {

    LinearLayout mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBManager dbManager = new DBManager(getApplicationContext());
        dbManager.open();
        dbManager.cc();

        mainLayout = findViewById(R.id.mainLayout);

        new CountDownTimer(3000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                startActivity(new Intent(getApplicationContext(), WelcomePage.class));
            }
        }.start();

//        mainLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(), WelcomePage.class));
//            }
//        });

    }



}