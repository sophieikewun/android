package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.databasemadeeasy.R;

public class BasePage extends AppCompatActivity {
    ImageView homeFrag, courseFrag, notificationFrag, profileFrag, navID;

    FragmentContainerView fragmentContainerView;
    FragmentManager fm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_page);

//        MiddleWareSystem middleWareSystem = new MiddleWareSystem(getApplicationContext());
//        middleWareSystem.setMiddleFunction(1, 0);

//        cc();

        homeFrag = findViewById(R.id.homeFrag);
        courseFrag = findViewById(R.id.courseFrag);
        notificationFrag = findViewById(R.id.notificationFrag);
        profileFrag = findViewById(R.id.profileFrag);
        navID = findViewById(R.id.navID);
        fragmentContainerView = findViewById(R.id.fragmentContainerView);
        fm = getSupportFragmentManager();


        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if(bundle.containsKey("pageValue")) {
                try {
                    switchPage(Class.forName(getPackageName() + "." + bundle.getString("pageValue")));
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        homeFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Explore.class);
            }
        });
        courseFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Courses.class);
            }
        });
        notificationFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Notification.class);
            }
        });
        profileFrag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchPage(Profile.class);
            }
        });
        navID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Menu.class));
            }
        });

    }

    public void switchPage(Class className) {
        fm.beginTransaction()
                .replace(R.id.fragmentContainerView, className, null)
                .setReorderingAllowed(true)
                .addToBackStack("name")
                .commit();
    }
}