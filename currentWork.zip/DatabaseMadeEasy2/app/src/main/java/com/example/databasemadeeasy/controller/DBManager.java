package com.example.databasemadeeasy.controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.example.databasemadeeasy.model.QuizContract.*;
import com.example.databasemadeeasy.model.IndividualQuestion;
import com.example.databasemadeeasy.model.Question;
import com.example.databasemadeeasy.view.Category;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DBManager {
    DBHelper dbHelper;
    Context context;
    SQLiteDatabase sqLiteDatabaseWriter;
    SQLiteDatabase sqLiteDatabaseReader;
    private static DBManager instance;

    public DBManager(Context context) {
        this.context = context;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DBHelper(context);
        sqLiteDatabaseWriter = dbHelper.getWritableDatabase();
        sqLiteDatabaseReader = dbHelper.getReadableDatabase();
        return this;
    }

    public static synchronized DBManager getInstance(Context context) {
        if (instance == null) {
            instance = new DBManager(context.getApplicationContext());
        }
        return instance;
    }

    public void close() {
        dbHelper.close();
    }

    // Insert Statement

    public void insertScore(int userId, int courseId, int score) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("score", score);
        long result = sqLiteDatabaseWriter.insert("score", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertCategory(String categoryName) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("categoryName", categoryName);
        long result = sqLiteDatabaseWriter.insert("category", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public long insertUser(String fullName, String email, String password, int role, int activated) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("fullName", fullName);
        contentValues.put("email", email);
        contentValues.put("password", password);
        contentValues.put("role", role);
        contentValues.put("activated", activated);
        long result = sqLiteDatabaseWriter.insert("user", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }

        return result;
    }

    public void insertCourse(String courseName, String description, String excerpt, String lastModified, int categoryId) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("courseName", courseName);
        contentValues.put("description", description);
        contentValues.put("excerpt", excerpt);
        contentValues.put("lastModified", lastModified);
        contentValues.put("categoryId", categoryId);
        long result = sqLiteDatabaseWriter.insert("course", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertShelf(int userId, int courseId, int completed) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("courseId", courseId);
        contentValues.put("completed", completed);
        long result = sqLiteDatabaseWriter.insert("shelf", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertTestScore(int userId, int questionId) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("questionId", questionId);
        long result = sqLiteDatabaseWriter.insert("testScore", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }


    public void insertOtp(long userId, int otp_code, String timeToExpire) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("otp_code", otp_code);
        contentValues.put("timeToExpire", timeToExpire);
        long result = sqLiteDatabaseWriter.insert("otp", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success OTP", Toast.LENGTH_SHORT).show();
        }
    }

    public void insertNotification(int userId, String message, String timestamp, String title) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("message", message);
        contentValues.put("timestamp", timestamp);
        contentValues.put("title", title);
        long result = sqLiteDatabaseWriter.insert("notification", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }

    public long insertGroup(String title, String description, String link) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("title", title);
        contentValues.put("description", description);
        contentValues.put("link", link);
        long result = sqLiteDatabaseWriter.insert("groups", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    public void insertGroupMember(String userId, String groupsId) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("userId", userId);
        contentValues.put("groupsId", groupsId);
        long result = sqLiteDatabaseWriter.insert("groupmembers", null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }


    private void fillCategoriesTable() {
        Category c1 = new Category("Beginner");
        addCategory(c1);
        Category c2 = new Category("Intermediate");
        addCategory(c2);
        Category c3 = new Category("Advanced");
        addCategory(c3);
        Category c4 = new Category("Expert");
        addCategory(c4);
    }

    private void fillQuestionTable() {
        Toast.makeText(context.getApplicationContext(), "Fill ques", Toast.LENGTH_SHORT).show();
        Question q1 = new Question("A relation is represented as a what?", "Two-dimensional table containing rows and columns", "Structure and dimension ", "concepts and categories", 1, 1);
        insertQuestion(q1);
        Question q2 = new Question("What do relations hold?", "Numbers", "Information", "Input", 2, 1);
        insertQuestion(q2);
        Question q3 = new Question("What do rows correspond to in a relation?", "Multiple sources", "Plain text", "Individual records", 3, 1);
        insertQuestion(q3);
        Question q4 = new Question("What do Columns correspond to in a relation? ", "Attributes", "Personality", "Data", 1, 1);
        insertQuestion(q4);
        Question q5 = new Question("Is the order of an attribute important in a relation?", "No", "Yes", "Always", 2, 1);
        insertQuestion(q5);
        Question q6 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q6);
        Question q7 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q7);
        Question q8 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q8);
        Question q9 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q9);
        Question q10 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 2);
        insertQuestion(q10);
        Question q11 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q11);
        Question q12 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q12);
        Question q13 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q13);
        Question q14 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q14);
        Question q15 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertQuestion(q15);
        Question q16 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q16);
        Question q17 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q17);
        Question q18 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q18);
        Question q19 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q19);
        Question q20 = new Question("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertQuestion(q20);
    }


    private void fillIndividualCourseQuestionsTable() {
        Toast.makeText(context.getApplicationContext(), "Individual Question", Toast.LENGTH_SHORT).show();

        IndividualQuestion q1 = new IndividualQuestion("What do relations hold?", "Information", "Input", "Numbers", 1, 1);
        insertIndividualCourseQuestion(q1);
        IndividualQuestion q2 = new IndividualQuestion("What do rows correspond to in a relation?", "Multiple sources", "Individual records", "Plain text", 2, 1);
        insertIndividualCourseQuestion(q2);
        IndividualQuestion q3 = new IndividualQuestion("What do Columns correspond to in a relation?", "Personality", "Data", "Attributes", 3, 1);
        insertIndividualCourseQuestion(q3);

        IndividualQuestion q4 = new IndividualQuestion("How do you uniquely identify each row in a relation", "Using Keys", "Assigning unique values", "Plain text", 1, 2);
        insertIndividualCourseQuestion(q4);
        IndividualQuestion q5 = new IndividualQuestion("What is a problem with superkeys", "They are super", "They may contain attributes that are not strictly unique", "They are always unique", 2, 2);
        insertIndividualCourseQuestion(q5);
        IndividualQuestion q6 = new IndividualQuestion("What is a key that represents a relationship between records of a relation", "Candidate key", "Foreign key", "Superkey", 2, 2);
        insertIndividualCourseQuestion(q6);

        IndividualQuestion q7 = new IndividualQuestion("What makes the storage of data more efficient", "Optionality", "Normalization", "Standardization", 2, 3);
        insertIndividualCourseQuestion(q7);
        IndividualQuestion q8 = new IndividualQuestion("Which of the following is a 1NF problem", "Execution", "Update anomaly", "", 2, 3);
        insertIndividualCourseQuestion(q8);
        IndividualQuestion q9 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 3);
        insertIndividualCourseQuestion(q9);

        IndividualQuestion q10 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertIndividualCourseQuestion(q10);
        IndividualQuestion q11 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertIndividualCourseQuestion(q11);
        IndividualQuestion q12 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 4);
        insertIndividualCourseQuestion(q12);

        IndividualQuestion q13 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 5);
        insertIndividualCourseQuestion(q13);
        IndividualQuestion q14 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 5);
        insertIndividualCourseQuestion(q14);
        IndividualQuestion q15 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 5);
        insertIndividualCourseQuestion(q15);

        IndividualQuestion q16 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 6);
        insertIndividualCourseQuestion(q16);
        IndividualQuestion q17 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 6);
        insertIndividualCourseQuestion(q17);
        IndividualQuestion q18 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 6);
        insertIndividualCourseQuestion(q18);

        IndividualQuestion q19 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 7);
        insertIndividualCourseQuestion(q19);
        IndividualQuestion q20 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 7);
        insertIndividualCourseQuestion(q20);
        IndividualQuestion q21 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 7);
        insertIndividualCourseQuestion(q21);

        IndividualQuestion q22 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 8);
        insertIndividualCourseQuestion(q22);
        IndividualQuestion q23 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 8);
        insertIndividualCourseQuestion(q23);
        IndividualQuestion q24 = new IndividualQuestion("thank you Jesus`1wq", "A", "B", "c", 2, 8);
        insertIndividualCourseQuestion(q24);
    }

    private void addCategory(Category category) {
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, category.getName());
        sqLiteDatabaseWriter.insert(CategoriesTable.TABLE_NAME, null, cv);
    }

    private void insertQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionTable.COLUMN_CATEGORY_ID, question.getCategoryID());
        sqLiteDatabaseWriter.insert(QuestionTable.TABLE_NAME, null, cv);
    }

    private void insertIndividualCourseQuestion(IndividualQuestion question) {
        ContentValues cv = new ContentValues();
        cv.put("question", question.getQuestion());
        cv.put("option1", question.getOption1());
        cv.put("option2", question.getOption2());
        cv.put("option3", question.getOption3());
        cv.put("answerNr", question.getAnswerNr());
        cv.put("courseId", question.getCourseID());
        sqLiteDatabaseWriter.insert("individualCourseQuestions", null, cv);
    }


    public Cursor fetchGroupMembers(String groupId) {
        String query = "Select fullname from user where userId in (Select userId from groupmembers where groupsId = " + '"' + groupId + '"' + ");";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchGroupMemberAvailability(String groupId, String userId) {
        String query = "Select * from groupmembers where groupsId = " + '"' + groupId + '"' + "  AND userId = " + '"' + userId + '"';

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchGroupMemberGroups(String userId) {
        String query = "Select * from groups where groupId in (Select groupsId from groupmembers where userId = " + '"' + userId + '"' + ");";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchAllData(String tableName) {

        String query = "Select * from " + tableName;

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataById(String tableName, String id, String tableColumn) {
        String query = "Select * from " + tableName + " where " + '"' + tableColumn + '"' + " = " + "'" + id + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor fetchDataBySpecificColumn(String tableName, String columnValue, String tableColumn) {
        String query = "Select * from " + tableName + " where " + tableColumn + " = " + "'" + columnValue + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchCourseStudentDetail(int courseId) {
        String query = "Select count(courseId) from shelf where courseId = " + '"' + courseId + '"';

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchShelfData(String shelfType, String userId) {

        String query = "Select c.courseId, c.courseName, c.lastModified, c.categoryId from course c where courseId in (select courseId from shelf where userId = " + "'" + userId + "' AND completed = " + "'" + shelfType + "');";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchCourseStudentEnrolled(String userId, String courseId) {
        String query = "Select * from shelf where userId = " + "'" + userId + "' AND courseId = " + "'" + courseId + "';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchPopularCourse() {
        String query = "select * from course where courseId in (select courseId from shelf group by courseId order by count(*) desc LIMIT 4);";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        return cursor;
    }

    public Cursor fetchOtpCode(String userId) {
        String query = "select otp_code, timeToExpire from otp where userId = " + "'" + userId + "' order by otpId DESC LIMIT 1;";
        //        String query = "select * from otp where userId = " + userId +  " order by otpId DESC LIMIT 1;";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public List<Category> getAllCategories() {
        List<Category> categoryList = new ArrayList<>();
        String query = "SELECT * FROM " + '"' + "category" + '"' + ";";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Category category = new Category();
                category.setId(cursor.getInt(0));
                category.setName(cursor.getString(1));
                categoryList.add(category);
            }
        }


        return categoryList;
    }

    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionList = new ArrayList<>();
        Cursor c = sqLiteDatabaseReader.rawQuery(" SELECT * FROM " + QuestionTable.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(0));
                question.setQuestion(c.getString(1));
                question.setOption1(c.getString(2));
                question.setOption2(c.getString(3));
                question.setOption3(c.getString(4));
                question.setAnswerNr(c.getInt(5));
                question.setCategoryID(c.getInt(6));
                questionList.add(question);

            } while (c.moveToNext());

        }
        c.close();
        return questionList;
    }

    public ArrayList<Question> getQuestions(int categoryID) {
        ArrayList<Question> questionList = new ArrayList<>();
        String selection = QuestionTable.COLUMN_CATEGORY_ID + " = ? ";

        String[] selectionArgs = new String[]{String.valueOf(categoryID)};

        Cursor c = sqLiteDatabaseReader.query(
                QuestionTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(0));
                question.setQuestion(c.getString(1));
                question.setOption1(c.getString(2));
                question.setOption2(c.getString(3));
                question.setOption3(c.getString(4));
                question.setAnswerNr(c.getInt(5));
                question.setCategoryID(c.getInt(6));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }


    public ArrayList<IndividualQuestion> getIndividualCourseQuestions(String courseID) {
        String query = "select * from individualCourseQuestions where courseId = " + courseID + ";";
        ArrayList<IndividualQuestion> questionList = new ArrayList<>();


        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }

        while(cursor.moveToNext()) {
            IndividualQuestion question = new IndividualQuestion();
            question.setId(cursor.getInt(0));
            question.setQuestion(cursor.getString(1));
            question.setOption1(cursor.getString(2));
            question.setOption2(cursor.getString(3));
            question.setOption3(cursor.getString(4));
            question.setAnswerNr(cursor.getInt(5));
            question.setCourseID(cursor.getInt(6));
            questionList.add(question);
        }
        return questionList;
    }


    public void updateUserPassword(String user_id, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("password", password);

        int query = sqLiteDatabaseWriter.update("user", contentValues, "userId" + " = " + user_id, null);

        if (query == -1) {
            Toast.makeText(context, "Password failed to update ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Password updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    public void updateUserActivation(String user_id, int activation_value) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("activated", activation_value);

        int query = sqLiteDatabaseWriter.update("user", contentValues, "userId" + " = " + user_id, null);

        if (query == -1) {
            Toast.makeText(context, "Account failed to update ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Account updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    public int updateCourseCompleted(String user_id, String courseId, int completed) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("completed", completed);

        int query = sqLiteDatabaseWriter.update("shelf", contentValues, "userId" + " = " + user_id + " and courseId = " + courseId, null);

        if (query == -1) {
            Toast.makeText(context, "User course completed failed to update ", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "User course completed updated successfully", Toast.LENGTH_SHORT).show();
        }

        return query;
    }


    public Cursor searchForCourse(String searchValue) {
        String query = "Select * from course where courseName like '%" + searchValue + "%';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }

    public Cursor searchForShelfCourse(String userId, String searchValue) {
        String query = "select * from (select * from course where courseId in (select courseId from shelf where userId = " + userId + ")) where courseName like '%" + searchValue + "%';";

        Cursor cursor = null;
        if (sqLiteDatabaseReader != null) {
            cursor = sqLiteDatabaseReader.rawQuery(query, null);
        }
        return cursor;
    }


    public void cc() {
        Cursor datas = null;
        if (sqLiteDatabaseReader != null) {
            String query = "select * from course";
            datas = sqLiteDatabaseReader.rawQuery(query, null);
        }

        if (datas.getCount() < 1) {

            SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            insertUser("Sample user", "sampleuser@mail.com", "samplee", 0, 1);
            insertUser("Sophia Ikewun", "sophiaikewun@mail.com", "samplee", 0, 1);
            insertUser("Ikewun Zoe", "ikewunzoe@mail.com", "samplee", 0, 1);
            insertUser("Zoe SAmple", "ikewunzoe1@mail.com", "samplee", 0, 1);
            insertUser("Smam Zoe", "ikewunzoe2@mail.com", "samplee", 0, 1);
            insertUser("III Zoe", "ikewunzoe3@mail.com", "samplee", 0, 1);
            insertUser("LMSDNK Zoe", "ikewunzoe4@mail.com", "samplee", 0, 1);
            insertUser("MNVMN Zoe", "ikewunzoe5@mail.com", "samplee", 0, 1);
            insertUser("Kdjfdfn Zoe", "ikewunzoe6@mail.com", "samplee", 0, 1);

            insertCategory("Beginner");
            insertCategory("Intermediate");
            insertCategory("Advanced");
            insertCategory("Expert");

            insertCourse("Introduction to Database", "The relational data model was first proposed by Edward Codd in a\n" +
                    "paper written in 1970.\n" +
                    "• The relational model has a sound theoretical foundation, which is\n" +
                    "lacking in some of the other models.\n" +
                    "• The objectives of the relational model are:\n" +
                    "– To allow a high degree of data independence. Users’ interactions with the\n" +
                    "database must not be affected by changes to the internal view of data,\n" +
                    "particularly record orderings and access paths.\n" +
                    "– To provide substantial grounds for dealing with the problems of data\n" +
                    "semantics, consistency, and redundancy. In particular, Codd’s paper\n" +
                    "introduces the concept of normalised relations (details later).\n" +
                    "– To enable the use of set-oriented data manipulation languages " +
                    "" +
                    "One of the most significant implementations of the relational model\n" +
                    "was System R which was developed by IBM during the late 1970’s.\n" +
                    "• System R was intended as a “proof of concept” to show that relational\n" +
                    "database systems could really be built and work efficiently.\n" +
                    "• It gave rise to two major developments:\n" +
                    "– A structured query language called SQL which has since become an ISO\n" +
                    "standard and de facto standard relational language.\n" +
                    "– The production of various commercial relational DBMS products during\n" +
                    "the 1980s such as DB2, SQL/DS, and ORACLE.\n" +
                    "• There are now several hundred relational database systems.\n" +
                    "– Both commercial and open source" +
                    "" +
                    "The relational model is based on the mathematical concept of a relation.\n" +
                    "– Since Codd was a mathematician, he used terminology from that field, in\n" +
                    "particular set theory and logic.\n" +
                    "– We will not deal with these concepts as such, but we need to understand\n" +
                    "the terminology as it relates to the relational data model.\n" +
                    "• A relation is represented as a two-dimensional table containing rows\n" +
                    "and columns (much like a spreadsheet).\n" +
                    "• Relations are used to hold information about the entities to be\n" +
                    "represented in the database.\n" +
                    "– The rows correspond to individual records.\n" +
                    "– The columns correspond to attributes or fields.\n" +
                    "– The order of the attributes is unimportant. They can appear in any order\n" +
                    "and the relation will remain the same.", "Logically related data that represents the entities, attributes,\n" +
                    "and relationships of an organisation’s information", sdf3.format(new Timestamp(System.currentTimeMillis())), 1);

            insertCourse("Database Keys", "We need to be able to identify uniquely each row in a relation by the\n" +
                    "values of its attributes.\n" +
                    "– This enables a particular row to be retrieved or related to other records.\n" +
                    "• We use relational keys for this purpose. These consist of a chosen\n" +
                    "attribute or set of attributes from the relation in question. " +
                    "" +
                    "Superkeys\n" +
                    "• A superkey is any attribute or set of attributes that uniquely identifies a\n" +
                    "particular row within a relation. Problem with Superkeys\n" +
                    "• The problem with superkeys is that they may contain attributes that are\n" +
                    "not strictly required for unique identification." +
                    "Ideally, we are interested in the superkeys that contain only the\n" +
                    "attributes necessary for unique identification. Candidate Keys\n" +
                    "• If a superkey does not contain any superfluous attributes, we say\n" +
                    "that it is minimal. More formally:\n" +
                    "– A superkey is minimal if removing any attributes would mean that it no\n" +
                    "longer provides unique identification.\n" +
                    "• When choosing a key for a relation, we may pick any minimal\n" +
                    "superkey. Minimal superkeys are therefore called candidate keys. Properties of Candidate Keys\n" +
                    "• A candidate key, K, for a relation R has the following properties:\n" +
                    "• Uniqueness:\n" +
                    "– In each row of R, the values of K uniquely identify that row.\n" +
                    "– In other words: no two rows of R can have the same values for K.\n" +
                    "• Irreducibility:\n" +
                    "– No subset of K has the uniqueness property.\n" +
                    "– Therefore, K cannot consist of fewer attributes.\n" +
                    "• The above is simply a formal way of stating what we know about\n" +
                    "candidate keys.\n" +
                    "• Some relations may have several candidate keys. " +
                    "" +
                    "Primary Keys " +
                    "" +
                    "For each relation in the database, we must choose one of its candidate\n" +
                    "keys to be its primary key.\n" +
                    "• Since a relation cannot have duplicate rows (by definition), it is always\n" +
                    "possible to uniquely identify each row.\n" +
                    "– This means that in theory every relation has at least one candidate key.\n" +
                    "– Hence, a primary key can always be found.\n" +
                    "– In the worst case, the entire set of attributes could serve as the primary\n" +
                    "key, but usually some smaller subset is sufficient.\n" +
                    "• However, since many database systems allow relations to contain\n" +
                    "duplicates, this theoretical property does not necessarily apply in\n" +
                    "practice. Foreign Key  When an attribute appears in more than one relation, its appearance\n" +
                    "usually represents a relationship between records of the relations, When the primary key of one relation appears as an attribute in another\n" +
                    "relation it is called a foreign key", "We need to be able to identify uniquely each row in a relation by the\n" +
                    "values of its attributes.", sdf3.format(new Timestamp(System.currentTimeMillis())), 1);


            insertCourse("Database Design", "E(Enhanced)ER Modelling\n" +
                            "• Complexity of the data make it difficult to use the traditional ER\n" +
                            "model.\n" +
                            "• To reduce this complexity of modelling:\n" +
                            "– improvements or enhancements to the existing ER model to\n" +
                            "make it able to handle the complex application in a better\n" +
                            "way.\n" +
                            "• A diagrammatic technique for displaying the Sub Class and\n" +
                            "Super Class; Specialization and Generalization; Aggregation etc.\n" +
                            "• It is based on developing the features for representing\n" +
                            "supertype/subtype relationships. Generalization/Specialization\n" +
                            "• Associated with special types of entities known as superclasses and\n" +
                            "subclasses.\n" +
                            "• Specialisation is the process of defining a set of subclasses.\n" +
                            "• Specialized classes are often called subclass while a generalized class\n" +
                            "is called a superclass." +
                            "Superclasses and Subclasses\n" +
                            "• An entity type represents a set of entities of the same type such as Staff,\n" +
                            "Branch, and PropertyForRent. We can also form entity types into a\n" +
                            "hierarchy containing superclasses and subclasses.\n" +
                            "• Superclass: An entity type that includes one or more distinct\n" +
                            "subgroupings of its occurrences, which require to be represented in a\n" +
                            "data model:\n" +
                            "• Subclass: A distinct subgrouping of occurrences of an entity type,\n" +
                            "which require to be represented in a data model.\n" +
                            "• For example, the entities that are members of the Staff entity type\n" +
                            "may be classified as Manager, SalesPersonnel, and Secretary. In\n" +
                            "other words, the Staff entity is referred to as the superclass of the Manager, SalesPersonnel, and Secretary subclasses.",

                    "An entity–relationship model (or ER model) describes interrelated things of interest in a specific domain of knowledge. ", sdf3.format(new Timestamp(System.currentTimeMillis())), 2);


            insertCourse("Advanced SQL", "Creating a Table\n" +
                    "• The simplest form of SQL CREATE TABLE looks like:\n" +
                    "CREATE TABLE IF NOT EXISTS tablename\n" +
                    "(colname datatype,\n" +
                    "... )\n" +
                    "CREATE TABLE Staff\n" +
                    "(Sno INT,\n" +
                    "Sname VARCHAR2(20),\n" +
                    "Dept VARCHAR2(20),\n" +
                    "Grade VARCHAR2(7)) " +
                    "" +
                    "Data Types\n" +
                    "• Data types include:\n" +
                    "– VARCHAR2 variable length text strings\n" +
                    "– INT integers\n" +
                    "– DECIMAL numbers with decimal places\n" +
                    "– DATE full date (yyyy-mm-dd)\n" +
                    "• Dates have a default form of DD-MON-YY\n" +
                    "• EG: ‘09-MAR-17’ The apostrophes are required.  Table Constraints\n" +
                    "•    Data types " +
                    "" +
                    "The specification of a column can include some extras:\n" +
                    "– default value (used if an insertion doesn't supply a value)\n" +
                    "– and a column constraint (next slide)\n" +
                    "• We can add table constraint(s) before the closing\n" +
                    "bracket " +
                    "" +
                    " Data Integrity\n" +
                    "• Column constraints\n" +
                    "– enforcing entity and referential integrity\n" +
                    "[NOT NULL | NULL]\n" +
                    "[DEFAULT default_value]\n" +
                    "[AUTO_INCREMENT]\n" +
                    "[UNIQUE [KEY] | [PRIMARY] KEY]\n" +
                    "[COMMENT 'string']\n" +
                    "PRIMARY KEY (only one per table)\n" +
                    "FOREIGN KEY REFERENCES table (column) " +
                    "" +
                    "Data Integrity: Foreign Keys\n" +
                    "• The last of these declares a foreign key:\n" +
                    "CREATE TABLE Staff\n" +
                    "( ...\n" +
                    "Dept VARCHAR2(20) FOREIGN KEY REFERENCES Depts(Dname),\n" +
                    "Grade VARCHAR2(7) FOREIGN KEY REFERENCES Paytable\n" +
                    ")", "advanced SQL subjects include transactions, normal forms, main and foreign keys, hierarchical queries, triggers, indices, stored procedures, and much more. ", sdf3.format(new Timestamp(System.currentTimeMillis())), 2);


            insertCourse("Normalisation", "Normalisation of your database is a good thing\n" +
                    "– It makes the storage of data more efficient\n" +
                    "– It simplifies maintenance of the data\n" +
                    "• There are lots of normal forms\n" +
                    "– 1NF, 2NF, 3NF, BCNF, 4NF, 5NF\n" +
                    "• We will go through some of these, identifying the problems at each stage to motivate the next\n" +
                    "stage.\n" +
                    "– We will stop at 3NF" +
                    "" +
                    " Normalisation\n" +
                    "• What makes a well-designed set of relations? Are some relations better\n" +
                    "than others? Do we know what a relation is?\n" +
                    "• Also, what should we do if we are given an informally set-up table of data\n" +
                    "and asked to convert this to a relational database?\n" +
                    "• Usually, if we have designed a database from scratch using E-R modelling,\n" +
                    "we will end up with a well-designed set of relations.\n" +
                    "• But in other cases, we need to apply normalisation.\n" +
                    "• Example: We are given a table of newspaper readers and the newspapers\n" +
                    "they read. For example, reader Smith likes to read the Record and the Mail.\n" +
                    "We are asked to transform this table into a database. Achieving 1NF\n" +
                    "9\n" +
                    "• In general, to achieve 1NF we need to get rid of repeating groups in our tables. There are two\n" +
                    "alternative ways of doing this.\n" +
                    "• The one-table approach: we extend the table rows by replicating the non-repeated columns for each\n" +
                    "repeated item value. This is what we did in the previous slide.\n" +
                    "• The two-table approach: split the repeating and non-repeating data into separate tables (Non-loss\n" +
                    "Decomposition)\n" +
                    "– We must then choose a primary key for the repeating data table\n" +
                    "– …and insert this as a foreign key in the non-repeating data table\n" +
                    "• The two-table approach is often better as it takes up less space and leads us to 2nd Normal Form\n" +
                    "• First, other problems with 1NF Problems with a 1NF Relation: Update\n" +
                    "Anomalies\n" +
                    "12\n" +
                    "• Such repetition means that updates can be difficult.\n" +
                    "• Suppose that Smith goes on to a new grade.\n" +
                    "– Changes would be required to all records for Smith.\n" +
                    "– (And there is a danger that we may miss some.)\n" +
                    "• Suppose that the salary for grade 2.7 is changed.\n" +
                    "– All records for all staff members on grade 2.7 would have to be changed.\n" +
                    "• A fact should be stored only once. Updates are then problem-free.\n" +
                    "• This example relation is poorly structured, being subject to update anomalies." +
                    "A relation is in Second Normal Form (2NF) if\n" +
                    "– it is in 1NF and\n" +
                    "– every non-key column is fully FD (FFD) on the primary key.\n" +
                    "• The relation StaffBorrower is not in 2NF. Why not?\n" +
                    "– Because a non-key column (such as Sname) is not fully FD on the primary key (Sno,Bno • We can achieve 2NF by splitting our 1NF into two or more relations in 2NF. " +
                    "" +
                    "Third Normal Form\n" +
                    "27 Sno Sname Sdept Grade\n" +
                    "1 Smith Computing 2.7\n" +
                    "StaffBorrower3\n" +
                    "Grade Salary\n" +
                    "2.7 26813\n" +
                    "PayScale\n" +
                    "• A relation is in Third Normal Form (3NF) if\n" +
                    "– it is in 1NF + 2NF and\n" +
                    "– every non-key column is non-transitively fully FD on the primary key.\n" +
                    "• We can always find a decomposition into 3NF.\n" +
                    "• In our decomposition above, the Loan relation is already in 3NF:\n" +
                    "– the only non-key column is Date_out\n" +
                    "– the primary key is (Sno,Bno), and (Sno,Bno) → Date_out (i.e. FFD)\n" +
                    "• But (as we have seen) StaffBorrower2 is not in 3NF.\n" +
                    "• It is easy to see what to do ", "learn more about transforming ER\n" +
                    "data models into relational designs.\n" +
                    "• To turn customer’s requirements into\n" +
                    "well-formed relations by undergoing\n" +
                    "data normalisation.", sdf3.format(new Timestamp(System.currentTimeMillis())), 3);


            insertCourse("Relational Algebra", "Declarative versus Procedural\n" +
                    "• Theoretical background\n" +
                    "• Practical context of data analytics / ‘big data’ (Python and R)\n" +
                    "• Choices are not always clear\n" +
                    "• There are often no ‘right’ answers\n" +
                    "• Confusingly there are procedural elements within RDBMS\n" +
                    "• SQL/PSM (Persistent Stored Modules)\n" +
                    "• PL/SQL (Oracle), PL/pgSQL (PostreQSL), T-SQL (MS SQL Server)" +
                    "" +
                    "Declarative versus Procedural\n" +
                    "• Theoretical background\n" +
                    "• Practical context of data analytics / ‘big data’ (Python and R)\n" +
                    "• Choices are not always clear\n" +
                    "• There are often no ‘right’ answers\n" +
                    "• Confusingly there are procedural elements within RDBMS\n" +
                    "• SQL/PSM (Persistent Stored Modules)\n" +
                    "• PL/SQL (Oracle), PL/pgSQL (PostreQSL), T-SQL (MS SQL Server)" +
                    "" +
                    "Relational Algebra\n" +
                    "• the source of SQL’s flexibility/power\n" +
                    "RDBMS – based on tables (‘relations’ and ‘tuples’ in them) which\n" +
                    "adhere to an algebraic structure that allows reasoning and\n" +
                    "manipulation independent of the physical data representation\n" +
                    "• supports set manipulation\n" +
                    "• follows well defined rules\n" +
                    "• allows for simplification and optimisation" +
                    "" +
                    "Relational Algebra\n" +
                    "• Sometimes remembering that any SQL query must conform to the\n" +
                    "basic rules of relational algebra can be useful in trying to breakdown the purpose/structure of some (apparently) complex query\n" +
                    "that you might come across\n" +
                    "• In particular, the closure property of relational algebra mean that\n" +
                    "we can ‘chain’ operations together (nested / correlated queries)", "RDBMS – based on tables (‘relations’ and ‘tuples’ in them) which\n" +
                    "adhere to an algebraic structure that allows reasoning and\n" +
                    "manipulation independent of the physical data representation", sdf3.format(new Timestamp(System.currentTimeMillis())), 3);


            insertCourse("Procedural Extensions", "SQL/PSM (Persistent Stored Modules)\n" +
                    "• A little bit of history\n" +
                    "• Structure and ‘mechanics’ of PSM\n" +
                    "• Procedure ‘blocks’ (implicit and explicit structures)\n" +
                    "• structure\n" +
                    "• declaration and assignment\n" +
                    "• control structures\n" +
                    "• cursors\n" +
                    "• exceptions\n" +
                    "• procedures/functions/packages\n" +
                    "• triggers\n" +
                    "• PL/SQL (Oracle’s implementation of PSM)" +
                    "" +
                    "SQL/PSM (Persistent Stored Modules)\n" +
                    "• Procedure ‘blocks’\n" +
                    "• structure\n" +
                    "• declaration and assignment\n" +
                    "• control structures\n" +
                    "• cursors\n" +
                    "• exceptions\n" +
                    "• procedures/functions/packages\n" +
                    "• triggers" +
                    "" +
                    "PL/SQL – basic structure\n" +
                    "• Similar features to many imperative (‘high level’) programming\n" +
                    "languages: variables, constants, control structures, exception\n" +
                    "handling, modular code\n" +
                    "• Basic units: un-named ‘blocks’ (named: procedures and functions)\n" +
                    "• PL/SQL block [DECLARE Optional\n" +
                    "{list of declarations} ]\n" +
                    "BEGIN Mandatory\n" +
                    "{executable statements}\n" +
                    "[EXCEPTION Optional\n" +
                    "{code to handle exceptions} ]\n" +
                    "END; Mandatory" +
                    "" +
                    "PL/SQL – Declarations\n" +
                    "• Variables and constants must be declared before reference\n" +
                    "• If a variable is declared as ‘NOT NULL’ a value must be assigned\n" +
                    "• Can declare variables to be same type as a column in a table\n" +
                    "• or even define a variable to incorporate columns of an entire tuple\n" +
                    "vStudentNo VARCHAR2(5);\n" +
                    "vAge NUMBER(4,1) NOT NULL := 18;\n" +
                    "Max_Classes CONSTANT NUMBER := 50;\n" +
                    "vStudentNo Student.std_ID%TYPE;\n" +
                    "vStudentRec Student%ROWTYPE;\n" +
                    "%TYPE and %ROWTYPE – not standard SQL/PSM ", "• Sometimes ‘declarative’ is not enough", sdf3.format(new Timestamp(System.currentTimeMillis())), 4);


            insertCourse("NoSQL and 'post-relational' trends", "Confusion around “NoSQL”\n" +
                    "• Most commonly stands for “Not Only SQL”\n" +
                    "• Perhaps more useful to think of as post-relational databases\n" +
                    "• Multiple alternate types of NoSQL database exist\n" +
                    "• key-value / column / document / graph or RDF (+ multi-model)\n" +
                    "• There are effectively no (or very limited) standards\n" +
                    "• except some for querying (which look a lot like SQL!!)  " +
                    "" +
                    "Types of NoSQL Database\n" +
                    "• Key-Value stores\n" +
                    "• Columnar stores\n" +
                    "• Document databases\n" +
                    "• Graph databases", "Almost two decades of ‘post-relational’ (NoSQL) database evolution\n" +
                    "and still few agreed-upon definitions!", sdf3.format(new Timestamp(System.currentTimeMillis())), 4);

                /*
            //        insertNotification(1, "sample message subcription", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample1");
            //        dbManager.insertNotification(1, "Subscription User major", sdf3.format(new Timestamp(System.currentTimeMillis())), "sample2");
            //        dbManager.insertNotification(1, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
            //        dbManager.insertNotification(2, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
            //        dbManager.insertNotification(3, "Creative", sdf3.format(new Timestamp(System.currentTimeMillis())), "Sample3");
            //
            //        dbManager.insertShelf(1, 1, 0);
            //        dbManager.insertShelf(1, 2, 0);
            //        dbManager.insertShelf(1, 3, 0);
            //        dbManager.insertShelf(1, 4, 1);
            //        dbManager.insertShelf(1, 5, 0);
            //        dbManager.insertShelf(1, 6, 1);
            //        dbManager.insertShelf(2, 3, 0);
            //        dbManager.insertShelf(3, 5, 0);
            //
            //        dbManager.insertGroup("Group Sample", "This is a sample Group", "5e0cfa202fb14f31920be025e99ed084");
            //        dbManager.insertGroup("Group Sample1", "This is a sample Group", "4465f751acbe4ca6b3118221a7e83935");
            //
            //        dbManager.insertGroupMember("1", "1");
            //        dbManager.insertGroupMember("2", "1");
            //        dbManager.insertGroupMember("3", "1");
            //        dbManager.insertGroupMember("4", "1");
            //        dbManager.insertGroupMember("5", "1");
            //        dbManager.insertGroupMember("6", "2");
            //        dbManager.insertGroupMember("3", "2");
            //        dbManager.insertGroupMember("2", "2");
            */
            fillQuestionTable();
            fillIndividualCourseQuestionsTable();
        }
    }


}
