package com.example.databasemadeeasy.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.databasemadeeasy.view.GroupMainPage;
import com.example.databasemadeeasy.R;

import java.util.ArrayList;

public class AdapterGroup extends RecyclerView.Adapter<AdapterGroup.MyViewHolder> {

//    groupPageTitle


    private Context context;

    ArrayList<String> groupId, groupTitle;

    public AdapterGroup(Context context, ArrayList groupId, ArrayList groupTitle){
//        this.activity = activity;
        this.context = context;
        this.groupId = groupId;
        this.groupTitle = groupTitle;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_group, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.groupPageTitle.setText(String.valueOf(groupTitle.get(position)));
        //Recyclerview onClickListener
        holder.groupPageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, GroupMainPage.class);
                intent.putExtra("groupId", String.valueOf(groupId.get(position)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return this.groupId.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView groupPageTitle;
        LinearLayout groupPageLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            groupPageTitle = itemView.findViewById(R.id.groupPageTitle);
            groupPageLayout = itemView.findViewById(R.id.groupPageLayout);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
