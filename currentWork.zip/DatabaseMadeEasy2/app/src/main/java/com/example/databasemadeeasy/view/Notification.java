package com.example.databasemadeeasy.view;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;
import com.example.databasemadeeasy.adapter.AdapterNotification;

import java.util.ArrayList;

public class Notification extends Fragment {

    DBManager dbManager;
    ArrayList notificationIdList, notificationMessageList, notificationTitleList, notificationTimestampList;

    RecyclerView courseShelfProgRecycler;
    AdapterNotification adapterNotification;
    TextView emptyTextview;

    SharedPreferences sharedPreferences;
    String user_id;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notificatrion, container, false);

        notificationIdList = new ArrayList();
        notificationMessageList = new ArrayList();
        notificationTitleList = new ArrayList();
        notificationTimestampList = new ArrayList();

        courseShelfProgRecycler = view.findViewById(R.id.courseShelfProgRecycler1);
        emptyTextview = view.findViewById(R.id.emptyTextview);

        dbManager = new DBManager(getContext());

        sharedPreferences = getContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));

        storeDataInArrays();
        contentContainer();
        emptyTextview.setVisibility(View.VISIBLE);
        contentContainer ();

        return view;
    }

    public void contentContainer () {
        if(notificationIdList.size() > 0) {
            displayResult();
        }
        else {
            courseShelfProgRecycler.setVisibility(View.GONE);
            emptyTextview.setVisibility(View.VISIBLE);

        }
    }


    public void displayResult() {
        emptyTextview.setVisibility(View.GONE);
        courseShelfProgRecycler.setVisibility(View.VISIBLE);

        adapterNotification = new AdapterNotification(getContext(), notificationIdList, notificationMessageList, notificationTitleList, notificationTimestampList);
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(),1);

        courseShelfProgRecycler.setAdapter(adapterNotification);
        courseShelfProgRecycler.setLayoutManager(layoutManager);
    }

    public void storeDataInArrays() {
        dbManager.open();

        Cursor cursor = dbManager.fetchDataById("notification", user_id, "userId");

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                notificationIdList.add(cursor.getString(0));
                notificationMessageList.add(cursor.getString(2));
                notificationTitleList.add(cursor.getString(4));
                notificationTimestampList.add(cursor.getString(3));
            }
        }
    }

}