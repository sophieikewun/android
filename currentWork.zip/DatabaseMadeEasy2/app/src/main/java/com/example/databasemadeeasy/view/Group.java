package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;
import com.example.databasemadeeasy.adapter.AdapterGroup;

import java.util.ArrayList;

public class Group extends AppCompatActivity {

    TextView groupPageEmpty;
    ImageView backBtn;

    DBManager dbManager;
    ArrayList<String> groupId, groupTitle;

    RecyclerView courseMainRecycler;
    AdapterGroup adapterGroup;

    SharedPreferences sharedPreferences;
    String user_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group);


        backBtn = findViewById(R.id.imageView9);
        groupPageEmpty = findViewById(R.id.groupPageEmpty);
        courseMainRecycler = findViewById(R.id.courseCategoryMainRecycler21);

        groupId = new ArrayList<>();
        groupTitle = new ArrayList<>();


        dbManager = new DBManager(getApplicationContext());
        sharedPreferences = getApplicationContext().getSharedPreferences("mypref", getApplicationContext().MODE_PRIVATE);
        user_id = String.valueOf(sharedPreferences.getInt("userId", 0));



        storeDataInArrays();

        adapterGroup = new AdapterGroup(getApplicationContext(), groupId, groupTitle);

        GridLayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);


        courseMainRecycler.setAdapter(adapterGroup);
        courseMainRecycler.setLayoutManager(layoutManager);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    void storeDataInArrays() {
        dbManager.open();

        Cursor cursor = dbManager.fetchGroupMemberGroups(user_id);

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
            groupPageEmpty.setVisibility(View.VISIBLE);
        }
        else {
            groupPageEmpty.setVisibility(View.GONE);
            while(cursor.moveToNext()) {
                groupId.add(cursor.getString(0));
                groupTitle.add(cursor.getString(1));
            }
        }
    }
}