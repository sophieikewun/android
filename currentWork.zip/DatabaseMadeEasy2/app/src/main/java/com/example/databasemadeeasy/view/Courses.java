package com.example.databasemadeeasy.view;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.gridlayout.widget.GridLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;
import com.example.databasemadeeasy.adapter.AdapterCourseMain;

import java.util.ArrayList;

public class Courses extends Fragment {

    GridLayout courseGrid;
    Button searchBtn;
    DBManager dbManager;
    ArrayList<String> courseId, courseName, excerpt, lastModified, category;

    RecyclerView courseMainRecycler;
    AdapterCourseMain adapterCourseMain;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_courses, container, false);

        courseGrid = view.findViewById(R.id.courseGrid);
        searchBtn = view.findViewById(R.id.editTextTextPersonName9);
        courseMainRecycler = view.findViewById(R.id.courseMainRecycler);

        courseId = new ArrayList<>();
        courseName = new ArrayList<>();
        excerpt = new ArrayList<>();
        lastModified = new ArrayList<>();
        category = new ArrayList<>();


        dbManager = new DBManager(getContext());


        storeDataInArrays();

        adapterCourseMain = new AdapterCourseMain(view.getContext(), courseId, courseName, excerpt, lastModified, category);

        GridLayoutManager layoutManager = new GridLayoutManager(view.getContext(),2);


        courseMainRecycler.setAdapter(adapterCourseMain);
        courseMainRecycler.setLayoutManager(layoutManager);


        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(), SearchPage.class));
            }
        });


        courseGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(), Course_details.class));
            }
        });

        return view;
    }

    void storeDataInArrays() {
        DBManager dbManager = new DBManager(getContext());
        dbManager.open();

        Cursor cursor = dbManager.fetchAllData("course");

        if(cursor.getCount() == 0) {
            System.out.println("Empty");
        }
        else {
            while(cursor.moveToNext()) {
                courseId.add(cursor.getString(0));
                courseName.add(cursor.getString(1));
                excerpt.add(cursor.getString(3));
                lastModified.add(cursor.getString(4));
                category.add(cursor.getString(5));
            }
        }
    }

}