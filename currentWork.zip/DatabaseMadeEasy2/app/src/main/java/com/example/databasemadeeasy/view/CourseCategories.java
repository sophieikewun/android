package com.example.databasemadeeasy.view;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.example.databasemadeeasy.R;

public class CourseCategories extends Fragment {

    ImageView shelfBackBtn;
    FrameLayout beginnerCat, intermediateCat, advancedCat, expertCat;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_course_categories, container, false);
        shelfBackBtn = view.findViewById(R.id.shelfBackBtn);

        beginnerCat = view.findViewById(R.id.beginnerCat);
        intermediateCat = view.findViewById(R.id.intermediateCat);
        advancedCat = view.findViewById(R.id.advancedCat);
        expertCat = view.findViewById(R.id.expertCat);

        beginnerCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(1);
            }
        });
        intermediateCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(2);
            }
        });
        advancedCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(3);
            }
        });
        expertCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPage(4);
            }
        });


        shelfBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        return view;
    }

    void openPage(int categoryId) {
        Intent intent = new Intent(getContext(), CourseCategoryMain.class);
        intent.putExtra("categoryId", categoryId);
        startActivity(intent);
    }


}