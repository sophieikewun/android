package com.example.databasemadeeasy.model;

public class NotificationMessage {

    public String courseMessage(String courseTitle) {
        return "You have successfully enrolled in " + courseTitle + " and it has been added your shelf";
    }

    public String createGroupMessage(String groupTitle) {
        return groupTitle + " has been created successfully";
    }

    public String joinGroupMessage(String groupTitle) {
        return "You have joined a new Group. \nGroup Detail: " + groupTitle;
    }

    public String courseCompletedMessage(String groupTitle) {
        return "You have successfully completed " + groupTitle + " course";
    }


}
