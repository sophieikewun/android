package com.example.databasemadeeasy.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.databasemadeeasy.R;

import java.util.ArrayList;

public class AdapterGroupMember extends RecyclerView.Adapter<AdapterGroupMember.MyViewHolder> {

    private Context context;
    ArrayList<String> fullName;

    public AdapterGroupMember(Context context, ArrayList fullName){
        this.context = context;
        this.fullName = fullName;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_group_member, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.userFullNameDetail.setText(String.valueOf(fullName.get(position)));
    }

    @Override
    public int getItemCount() {
        return this.fullName.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView userFullNameDetail;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            userFullNameDetail = itemView.findViewById(R.id.userFullNameDetail);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
