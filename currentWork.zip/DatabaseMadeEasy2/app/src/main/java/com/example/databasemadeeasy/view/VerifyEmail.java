package com.example.databasemadeeasy.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class VerifyEmail extends AppCompatActivity {

    ImageView backBtn;
    Button verifyBtn;
    EditText otp1, otp2, otp3, otp4, otp5;
    TextView emailId, messageBox, resendBtn, resendText, resendBtn2;
    LinearLayout resendLayout;
    ArrayList<String> otpDetail;

    DBManager dbManager;
    SimpleDateFormat sdf3;

    String emailAddress;
    int userId;
    long expiry;
    int otp_code;

    boolean hidden = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_email);

        backBtn = findViewById(R.id.backBtn);
        verifyBtn = findViewById(R.id.verifyBtn);
        otp1 = findViewById(R.id.otp1);
        otp2 = findViewById(R.id.otp2);
        otp3 = findViewById(R.id.otp3);
        otp4 = findViewById(R.id.otp4);
        otp5 = findViewById(R.id.otp5);
        emailId = findViewById(R.id.emailId);
        messageBox = findViewById(R.id.messageBox3);
        resendBtn = findViewById(R.id.resendBtn);
        resendText = findViewById(R.id.resendText);
        resendLayout = findViewById(R.id.resendLayout);
        resendBtn2 = findViewById(R.id.resendBtn2);

        otpDetail = new ArrayList<>();

        Bundle extras = getIntent().getExtras();
        emailAddress = extras.getString("email");
        userId = extras.getInt("userId");

        dbManager = new DBManager(getApplicationContext());
        sdf3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        emailId.setText(emailAddress);

        setOTP();
        toggleResendBtn();


        resendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setOTP();
                resendLayout.setVisibility(View.GONE);
            }
        });

        resendBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int otp_code = (int) Math.floor(Math.random() * (90000 - 10000 + 1) + 10000);
                String timeToExpire = sdf3.format(new Timestamp(System.currentTimeMillis() + 1000 * 60 * 30));

                dbManager.insertOtp(userId, otp_code, timeToExpire);
                otp1.setText("");
                otp2.setText("");
                otp3.setText("");
                otp4.setText("");
                otp5.setText("");
                resendBtn2.setVisibility(View.INVISIBLE);
                hidden = false;
                setOTP();
                toggleResendBtn();
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otp1Value = otp1.getText().toString();
                String otp2Value = otp2.getText().toString();
                String otp3Value = otp3.getText().toString();
                String otp4Value = otp4.getText().toString();
                String otp5Value = otp5.getText().toString();

                if (otp1Value.isEmpty() || otp2Value.isEmpty() || otp3Value.isEmpty() || otp4Value.isEmpty() || otp5Value.isEmpty()) {
                    setMessageBox("All fields are mandatory");
                }
                else {
                    int otp = Integer.parseInt(otp1Value + otp2Value + otp3Value + otp4Value + otp5Value);

                    if(otp == otp_code) {
                        if (expiry > System.currentTimeMillis()) {
                            dbManager.open().updateUserActivation(String.valueOf(userId), 1);

                            otp1.setText("");
                            otp2.setText("");
                            otp3.setText("");
                            otp4.setText("");
                            otp5.setText("");

                            Intent intent = new Intent(getApplicationContext(), Account_created.class);
                            intent.putExtra("userId", userId);
                            startActivity(intent);
                        } else {
                            setMessageBox("Expired code");
                            resendBtn2.setVisibility(View.VISIBLE);
                            resendLayout.setVisibility(View.INVISIBLE);
                            hidden = true;
                        }
                    }
                    else {
                        setMessageBox("Incorrect OTP Code");
                    }
                }
            }
        });

        Number[] value = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57};

        otp1.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp2.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp2.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp3.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp3.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp4.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });

        otp4.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() != KeyEvent.ACTION_DOWN) {
                    if(Arrays.asList(value).contains(event.getUnicodeChar())) {
                        otp5.requestFocus();
                    }
                    return true;
                }
                return false;
            }
        });
    }

    public void setMessageBox(String message) {
        messageBox.setText(message);
        messageBox.setVisibility(View.VISIBLE);
        new CountDownTimer(1000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                messageBox.setVisibility(View.GONE);
            }
        }.start();
    }

    public void setOTP() {
        otpDetail = new ArrayList<>();

        Date date;
        dbManager.open();
        Cursor cursor =  dbManager.fetchOtpCode(String.valueOf(userId));

        if(cursor.getCount() > 0) {
            while(cursor.moveToNext()){
                otpDetail.add(cursor.getString(0));
                otpDetail.add(cursor.getString(1));
            }
        }

        try {
            date = sdf3.parse(otpDetail.get(1));
            expiry = date.getTime();
            otp_code = Integer.parseInt(otpDetail.get(0));
            Toast.makeText(getApplicationContext(), String.valueOf(otp_code), Toast.LENGTH_LONG).show();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    public void toggleResendBtn() {
        new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                if(hidden) {
                    resendLayout.setVisibility(View.INVISIBLE);
                } else {
                    resendLayout.setVisibility(View.VISIBLE);
                }
            }
        }.start();
    }


}