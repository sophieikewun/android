package com.example.databasemadeeasy.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.databasemadeeasy.view.Course_content;
import com.example.databasemadeeasy.controller.DBManager;
import com.example.databasemadeeasy.R;

import java.util.ArrayList;

public class AdapterShelf extends RecyclerView.Adapter<AdapterShelf.MyViewHolder> {
    private Context context;
    ArrayList<String> courseId, courseName, lastModified, category;

    public AdapterShelf(Context context, ArrayList courseId, ArrayList courseName, ArrayList lastModified, ArrayList category){
        this.context = context;
        this.courseId = courseId;
        this.courseName = courseName;
        this.lastModified = lastModified;
        this.category = category;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_progress, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.courseTitleDetail.setText(String.valueOf(courseName.get(position)));

        Cursor cursor = new DBManager(context.getApplicationContext()).open().fetchDataById("category", String.valueOf(category.get(position)), "categoryId");
        if(cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                holder.progressCategory.setText(cursor.getString(1));
            }
        }


        holder.mainLay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Course_content.class);
                intent.putExtra("courseId", String.valueOf(courseId.get(position)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.courseId.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView courseTitleDetail, progressCategory;
        LinearLayout mainLay;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            courseTitleDetail = itemView.findViewById(R.id.courseTitleDetail);
            mainLay = itemView.findViewById(R.id.mainLay);
            progressCategory = itemView.findViewById(R.id.progressCategory);

            //Animate Recyclerview
//            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
//            mainLayout.setAnimation(translate_anim);
        }

    }


}
